# RedTune para Android

Este proyecto es una aplicación web React/Vite preparada para empaquetarse como aplicación Android mediante Capacitor.

## Crear el APK automáticamente

1. Crea un repositorio en GitHub y sube todos los archivos de este proyecto a la rama `main`.
2. En el repositorio, abre **Actions** y selecciona **Build RedTune Android APK**.
3. Pulsa **Run workflow** (o espera a que termine el flujo que se ejecuta al subir cambios).
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **RedTune-debug-apk**.
5. Descomprime el artefacto en tu celular y abre `app-debug.apk`. Si Android lo solicita, permite instalar aplicaciones desde esa fuente.

El APK generado es de depuración para pruebas, no una versión firmada para publicar en Google Play. Este entorno no incluye Android SDK ni Gradle, por lo que no puede compilar el APK binario directamente aquí.
