import { Track } from '../types/music';

interface MediaSessionCallbacks {
  onPlay: () => void;
  onPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (time: number) => void;
}

let wakeLockSentinel: any = null;
let audioContext: AudioContext | null = null;
let backgroundCarrierGain: GainNode | null = null;
let isBackgroundEngineActive = false;

/**
 * Initializes an ultra-low gain audio oscillator carrier.
 * Browsers (mobile Chrome, iOS Safari, desktop) use audio element presence
 * to determine whether to allow background execution when screen is locked or tab minimized.
 */
export function enableBackgroundAudioEngine(): void {
  if (isBackgroundEngineActive) return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    audioContext = new AudioContextClass();
    const osc = audioContext.createOscillator();
    backgroundCarrierGain = audioContext.createGain();

    // Inaudible sub-bass frequency with near-zero gain keeps the OS audio thread active
    osc.type = 'sine';
    osc.frequency.setValueAtTime(30, audioContext.currentTime);
    backgroundCarrierGain.gain.setValueAtTime(0.0001, audioContext.currentTime);

    osc.connect(backgroundCarrierGain);
    backgroundCarrierGain.connect(audioContext.destination);
    osc.start();

    if (audioContext.state === 'suspended') {
      audioContext.resume().catch(() => {});
    }

    isBackgroundEngineActive = true;
  } catch (err) {
    console.warn('Could not initialize background audio engine:', err);
  }
}

export function resumeBackgroundAudioEngine(): void {
  if (audioContext && audioContext.state === 'suspended') {
    audioContext.resume().catch(() => {});
  }
}

/**
 * Request Screen WakeLock so device doesn't sleep while playing
 */
export async function requestScreenWakeLock(): Promise<boolean> {
  try {
    if ('wakeLock' in navigator) {
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => {
        wakeLockSentinel = null;
      });
      return true;
    }
  } catch (err) {
    console.warn('Wake Lock request ignored or unsupported:', err);
  }
  return false;
}

export function releaseScreenWakeLock(): void {
  if (wakeLockSentinel) {
    try {
      wakeLockSentinel.release();
    } catch {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

/**
 * Sync song with OS MediaSession for lockscreen, notifications, and car bluetooth controls
 */
export function updateMediaSession(track: Track | null, isPlaying: boolean, callbacks: MediaSessionCallbacks): void {
  if (!('mediaSession' in navigator)) return;

  if (!track) {
    navigator.mediaSession.metadata = null;
    return;
  }

  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist,
      album: track.album,
      artwork: [
        { src: track.thumbnail, sizes: '96x96', type: 'image/jpeg' },
        { src: track.thumbnail, sizes: '128x128', type: 'image/jpeg' },
        { src: track.thumbnail, sizes: '256x256', type: 'image/jpeg' },
        { src: track.thumbnail, sizes: '512x512', type: 'image/jpeg' }
      ]
    });

    navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';

    navigator.mediaSession.setActionHandler('play', () => {
      callbacks.onPlay();
      navigator.mediaSession.playbackState = 'playing';
    });

    navigator.mediaSession.setActionHandler('pause', () => {
      callbacks.onPause();
      navigator.mediaSession.playbackState = 'paused';
    });

    navigator.mediaSession.setActionHandler('previoustrack', () => {
      callbacks.onPrevious();
    });

    navigator.mediaSession.setActionHandler('nexttrack', () => {
      callbacks.onNext();
    });

    navigator.mediaSession.setActionHandler('seekto', (details) => {
      if (details.seekTime !== undefined && details.seekTime !== null) {
        callbacks.onSeek(details.seekTime);
      }
    });

    navigator.mediaSession.setActionHandler('seekbackward', () => {
      callbacks.onSeek(-10);
    });

    navigator.mediaSession.setActionHandler('seekforward', () => {
      callbacks.onSeek(10);
    });
  } catch (err) {
    console.warn('MediaSession handler configuration warning:', err);
  }
}
