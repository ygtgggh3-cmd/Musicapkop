declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

export type YTPlayerState = -1 | 0 | 1 | 2 | 3 | 5;

export interface YTPlayerCallbacks {
  onReady?: () => void;
  onStateChange?: (state: YTPlayerState) => void;
  onTimeUpdate?: (currentTime: number, duration: number) => void;
  onError?: (error: any) => void;
  onEnded?: () => void;
}

class YouTubeController {
  private player: any = null;
  private isApiReady = false;
  private isPlayerReady = false;
  private callbacks: YTPlayerCallbacks = {};
  private timeUpdateInterval: any = null;
  private pendingVideoId: string | null = null;
  private currentVideoId: string | null = null;

  constructor() {
    this.initApi();
  }

  private initApi() {
    if (typeof window === 'undefined') return;

    if (window.YT && window.YT.Player) {
      this.isApiReady = true;
      return;
    }

    const prevOnReady = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (prevOnReady) prevOnReady();
      this.isApiReady = true;
      if (this.pendingVideoId) {
        this.createPlayer(this.pendingVideoId);
      }
    };

    if (!document.querySelector('script[src*="youtube.com/iframe_api"]')) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      tag.async = true;
      document.head.appendChild(tag);
    }
  }

  public registerContainer(elementId: string, callbacks: YTPlayerCallbacks, initialVideoId?: string) {
    this.callbacks = callbacks;
    if (initialVideoId && initialVideoId.length === 11) {
      this.pendingVideoId = initialVideoId;
    }

    if (this.isApiReady && !this.player) {
      this.createPlayerInternal(elementId, this.pendingVideoId || 'jfKfPfyJRdk');
    } else {
      const checkReady = setInterval(() => {
        if (window.YT && window.YT.Player) {
          clearInterval(checkReady);
          this.isApiReady = true;
          this.createPlayerInternal(elementId, this.pendingVideoId || 'jfKfPfyJRdk');
        }
      }, 100);
    }
  }

  private createPlayer(videoId: string) {
    this.pendingVideoId = videoId;
    if (this.isApiReady) {
      this.createPlayerInternal('youtube-hidden-player', videoId);
    }
  }

  private createPlayerInternal(elementId: string, initialVideoId?: string) {
    if (this.player || !window.YT) return;

    const el = document.getElementById(elementId);
    if (!el) return;

    const safeVideoId = (initialVideoId && initialVideoId.length === 11)
      ? initialVideoId
      : (this.pendingVideoId && this.pendingVideoId.length === 11)
        ? this.pendingVideoId
        : 'jfKfPfyJRdk';

    try {
      this.player = new window.YT.Player(elementId, {
        height: '240',
        width: '320',
        videoId: safeVideoId,
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          rel: 0,
          playsinline: 1,
          enablejsapi: 1,
          origin: window.location.origin
        },
        events: {
          onReady: () => {
            this.isPlayerReady = true;
            this.callbacks.onReady?.();
            if (this.pendingVideoId) {
              const vid = this.pendingVideoId;
              this.pendingVideoId = null;
              this.loadAndPlay(vid);
            }
          },
          onStateChange: (event: any) => {
            const state = event.data as YTPlayerState;
            this.callbacks.onStateChange?.(state);

            if (state === 1) {
              // Playing: start progress interval
              this.startTimeTicker();
            } else {
              this.stopTimeTicker();
              if (state === 0) {
                // Video ended
                this.callbacks.onEnded?.();
              }
            }
          },
          onError: (event: any) => {
            console.warn('YouTube Player error code:', event.data);
            this.callbacks.onError?.(event.data);
          }
        }
      });
    } catch (err) {
      console.error('Failed to instantiate YouTube player:', err);
    }
  }

  private startTimeTicker() {
    this.stopTimeTicker();
    this.timeUpdateInterval = setInterval(() => {
      if (this.player && this.isPlayerReady && typeof this.player.getCurrentTime === 'function') {
        try {
          const current = this.player.getCurrentTime() || 0;
          const total = this.player.getDuration() || 0;
          this.callbacks.onTimeUpdate?.(current, total);
        } catch {
          // ignore transient poll error
        }
      }
    }, 400);
  }

  private stopTimeTicker() {
    if (this.timeUpdateInterval) {
      clearInterval(this.timeUpdateInterval);
      this.timeUpdateInterval = null;
    }
  }

  public loadAndPlay(videoId: string) {
    this.currentVideoId = videoId;
    if (!this.player || !this.isPlayerReady) {
      this.pendingVideoId = videoId;
      return;
    }

    try {
      this.player.loadVideoById({
        videoId: videoId,
        startSeconds: 0
      });
      this.player.playVideo();
    } catch (err) {
      console.warn('Error calling loadVideoById:', err);
    }
  }

  public play() {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.playVideo();
      } catch (err) {
        console.warn('Play error:', err);
      }
    }
  }

  public pause() {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.pauseVideo();
      } catch (err) {
        console.warn('Pause error:', err);
      }
    }
  }

  public seekTo(seconds: number) {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.seekTo(seconds, true);
      } catch (err) {
        console.warn('Seek error:', err);
      }
    }
  }

  public setVolume(volume0to100: number) {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.setVolume(Math.round(volume0to100));
      } catch (err) {
        console.warn('Volume error:', err);
      }
    }
  }

  public mute() {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.mute();
      } catch (err) {
        console.warn('Mute error:', err);
      }
    }
  }

  public unMute() {
    if (this.player && this.isPlayerReady) {
      try {
        this.player.unMute();
      } catch (err) {
        console.warn('UnMute error:', err);
      }
    }
  }

  public destroy() {
    this.stopTimeTicker();
    if (this.player && typeof this.player.destroy === 'function') {
      try {
        this.player.destroy();
      } catch {}
      this.player = null;
    }
    this.isPlayerReady = false;
  }
}

export const ytController = new YouTubeController();
