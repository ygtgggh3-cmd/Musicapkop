import { Track, Playlist } from '../types/music';
import { INITIAL_TRACKS, INITIAL_PLAYLISTS } from '../data/initialTracks';

const STORAGE_KEYS = {
  TRACKS: 'redtune_custom_tracks_v1',
  PLAYLISTS: 'redtune_custom_playlists_v1',
  LIKED: 'redtune_liked_track_ids_v1',
  RECENT: 'redtune_recent_track_ids_v1',
  SETTINGS: 'redtune_player_settings_v1'
};

export interface PlayerSettings {
  volume: number;
  repeatMode: 'off' | 'all' | 'one';
  isShuffled: boolean;
  backgroundKeepAlive: boolean;
}

export function loadStoredTracks(): Track[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRACKS);
    if (!raw) return INITIAL_TRACKS;
    const parsed = JSON.parse(raw) as Track[];
    // Merge initial tracks if not present
    const map = new Map<string, Track>();
    INITIAL_TRACKS.forEach(t => map.set(t.id, t));
    parsed.forEach(t => map.set(t.id, t));
    return Array.from(map.values());
  } catch (err) {
    console.error('Error loading tracks from storage', err);
    return INITIAL_TRACKS;
  }
}

export function saveStoredTracks(tracks: Track[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TRACKS, JSON.stringify(tracks));
  } catch (err) {
    console.error('Error saving tracks', err);
  }
}

export function loadStoredPlaylists(): Playlist[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PLAYLISTS);
    if (!raw) return INITIAL_PLAYLISTS;
    const parsed = JSON.parse(raw) as Playlist[];
    return parsed;
  } catch (err) {
    console.error('Error loading playlists', err);
    return INITIAL_PLAYLISTS;
  }
}

export function saveStoredPlaylists(playlists: Playlist[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PLAYLISTS, JSON.stringify(playlists));
  } catch (err) {
    console.error('Error saving playlists', err);
  }
}

export function loadPlayerSettings(): PlayerSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return { volume: 0.85, repeatMode: 'off', isShuffled: false, backgroundKeepAlive: true };
    return { ...{ volume: 0.85, repeatMode: 'off', isShuffled: false, backgroundKeepAlive: true }, ...JSON.parse(raw) };
  } catch {
    return { volume: 0.85, repeatMode: 'off', isShuffled: false, backgroundKeepAlive: true };
  }
}

export function savePlayerSettings(settings: PlayerSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Error saving player settings', err);
  }
}

export function loadRecentlyPlayedIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RECENT);
    return raw ? JSON.parse(raw) : ['track_1', 'track_2'];
  } catch {
    return [];
  }
}

export function saveRecentlyPlayedId(trackId: string): string[] {
  try {
    const current = loadRecentlyPlayedIds().filter(id => id !== trackId);
    const updated = [trackId, ...current].slice(0, 30);
    localStorage.setItem(STORAGE_KEYS.RECENT, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}
