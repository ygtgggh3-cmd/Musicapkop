export interface MiracastDeviceStatus {
  isSupported: boolean;
  isConnecting: boolean;
  isConnected: boolean;
  deviceName?: string;
  errorMessage?: string;
}

// BroadcastChannel for syncing multiple windows / second displays / Miracast receivers
const CHANNEL_NAME = 'redtune_miracast_channel';
let broadcastChannel: BroadcastChannel | null = null;

try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    broadcastChannel = new BroadcastChannel(CHANNEL_NAME);
  }
} catch {
  // fallback if BroadcastChannel is blocked
}

export function sendMiracastMessage(type: string, payload: any): void {
  if (!broadcastChannel) return;
  try {
    broadcastChannel.postMessage({ type, payload, timestamp: Date.now() });
  } catch (err) {
    console.warn('Miracast broadcast error:', err);
  }
}

export function subscribeToMiracastChannel(callback: (event: { type: string; payload: any }) => void): () => void {
  if (!broadcastChannel) {
    return () => {};
  }
  const handler = (ev: MessageEvent) => {
    if (ev.data && ev.data.type) {
      callback(ev.data);
    }
  };
  broadcastChannel.addEventListener('message', handler);
  return () => {
    broadcastChannel?.removeEventListener('message', handler);
  };
}

/**
 * Checks if the browser natively supports the W3C Presentation API (used for Miracast / Cast wireless displays)
 */
export function isPresentationApiSupported(): boolean {
  return typeof navigator !== 'undefined' && 'presentation' in navigator;
}

/**
 * Starts a native wireless presentation request (Miracast / Cast / Wireless Display)
 */
export async function startNativePresentation(displayUrl: string = '/#miracast-screen'): Promise<{ success: boolean; error?: string }> {
  try {
    if (isPresentationApiSupported() && (window as any).PresentationRequest) {
      const PresentationRequest = (window as any).PresentationRequest;
      const request = new PresentationRequest([displayUrl]);
      
      const connection = await request.start();
      connection.addEventListener('connect', () => {
        console.log('Connected to Wireless Miracast display');
      });
      connection.addEventListener('terminate', () => {
        console.log('Miracast display terminated');
      });
      return { success: true };
    } else {
      return { 
        success: false, 
        error: 'El navegador actual no soporta Presentation API nativa. Puedes usar el modo Pantalla Secundaria / Transmitir.' 
      };
    }
  } catch (err: any) {
    return { success: false, error: err?.message || 'No se pudo conectar a la pantalla inalámbrica Miracast.' };
  }
}

/**
 * Opens a dedicated popup / second screen window for casting to external displays or projectors
 */
export function openExternalDisplayWindow(): Window | null {
  const width = 1280;
  const height = 720;
  const left = (window.screen.width - width) / 2;
  const top = (window.screen.height - height) / 2;
  
  const popup = window.open(
    '/?mode=miracast-display',
    'RedTune_Miracast_Receiver',
    `width=${width},height=${height},top=${top},left=${left},menubar=no,toolbar=no,location=no,status=no`
  );
  return popup;
}
