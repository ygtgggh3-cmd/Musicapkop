export interface Track {
  id: string;
  youtubeId: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  thumbnail: string;
  genre: string;
  lyrics?: string[];
  isLiked?: boolean;
  addedAt?: number;
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  coverUrl?: string;
  accentColor?: string;
  trackIds: string[];
  createdAt: number;
  updatedAt: number;
  isSystem?: boolean;
  isFavorites?: boolean;
}

export type RepeatMode = 'off' | 'all' | 'one';

export interface PlayerState {
  isPlaying: boolean;
  currentTrack: Track | null;
  currentTime: number;
  duration: number;
  volume: number; // 0 to 1
  isMuted: boolean;
  repeatMode: RepeatMode;
  isShuffled: boolean;
  isLoading: boolean;
}

export type ActiveNavTab = 'home' | 'explore' | 'library' | 'miracast' | 'lyrics';
