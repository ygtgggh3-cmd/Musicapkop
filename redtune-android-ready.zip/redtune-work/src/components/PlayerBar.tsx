import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Repeat1, 
  Volume2, 
  VolumeX, 
  Heart, 
  Tv, 
  ListMusic, 
  FileMusic, 
  Maximize2
} from 'lucide-react';
import { Track, RepeatMode } from '../types/music';

interface PlayerBarProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  repeatMode: RepeatMode;
  isShuffled: boolean;
  isQueueOpen: boolean;
  isLyricsOpen: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onToggleRepeat: () => void;
  onToggleShuffle: () => void;
  onToggleLike: (trackId: string) => void;
  onToggleQueue: () => void;
  onToggleLyrics: () => void;
  onOpenMiracast: () => void;
  onOpenFullScreen: () => void;
}

export const PlayerBar: React.FC<PlayerBarProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  repeatMode,
  isShuffled,
  isQueueOpen,
  isLyricsOpen,
  onPlayPause,
  onNext,
  onPrevious,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onToggleRepeat,
  onToggleShuffle,
  onToggleLike,
  onToggleQueue,
  onToggleLyrics,
  onOpenMiracast,
  onOpenFullScreen
}) => {
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekValue, setSeekValue] = useState(0);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSeekValue(val);
  };

  const handleSliderStart = () => {
    setIsSeeking(true);
    setSeekValue(currentTime);
  };

  const handleSliderEnd = () => {
    setIsSeeking(false);
    onSeek(seekValue);
  };

  const displayTime = isSeeking ? seekValue : currentTime;
  const progressPercent = duration > 0 ? (displayTime / duration) * 100 : 0;

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-40 bg-[#0c0c0c]/95 border-t border-white/5 backdrop-blur-xl select-none">
      {/* Top micro progress bar for quick visual feedback */}
      <div className="w-full bg-white/5 h-[2px] relative group cursor-pointer">
        <div 
          className="h-full bg-[#ff0033] relative transition-all"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="max-w-[1600px] mx-auto px-4 md:px-6 h-20 flex items-center justify-between gap-4">
        {/* Left Slot: Track Information & Like */}
        <div className="flex items-center gap-3 w-1/4 min-w-[180px] max-w-xs">
          {currentTrack ? (
            <>
              <button
                onClick={onOpenFullScreen}
                className="w-12 h-12 rounded-xl overflow-hidden shrink-0 relative group shadow-md"
              >
                <img
                  src={currentTrack.thumbnail}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Maximize2 className="w-4 h-4 text-white" />
                </div>
              </button>

              <div className="min-w-0">
                <button
                  onClick={onOpenFullScreen}
                  className="text-xs md:text-sm font-semibold text-white truncate hover:underline text-left block w-full"
                >
                  {currentTrack.title}
                </button>
                <p className="text-[11px] text-neutral-400 truncate mt-0.5">
                  {currentTrack.artist}
                </p>
              </div>

              <button
                onClick={() => onToggleLike(currentTrack.id)}
                className={`p-2 rounded-full transition-colors ${
                  currentTrack.isLiked ? 'text-[#ff0033]' : 'text-neutral-500 hover:text-neutral-300'
                }`}
                title={currentTrack.isLiked ? 'Quitar de favoritos' : 'Añadir a favoritos'}
              >
                <Heart className={`w-4 h-4 ${currentTrack.isLiked ? 'fill-current' : ''}`} />
              </button>
            </>
          ) : (
            <div className="text-xs text-neutral-500">
              Ninguna canción seleccionada
            </div>
          )}
        </div>

        {/* Center Slot: Playback Controls & Scrubber */}
        <div className="flex flex-col items-center justify-center flex-1 max-w-2xl px-2">
          {/* Main Control Buttons */}
          <div className="flex items-center gap-4 md:gap-6 mb-1">
            <button
              onClick={onToggleShuffle}
              className={`p-2 rounded-full transition-colors ${
                isShuffled ? 'text-[#ff0033]' : 'text-neutral-400 hover:text-white'
              }`}
              title={isShuffled ? 'Desactivar aleatorio' : 'Activar aleatorio'}
            >
              <Shuffle className="w-4 h-4" />
            </button>

            <button
              onClick={onPrevious}
              disabled={!currentTrack}
              className="p-2 text-neutral-300 hover:text-white disabled:opacity-30 transition-colors"
              title="Anterior canción"
            >
              <SkipBack className="w-5 h-5" />
            </button>

            <button
              onClick={onPlayPause}
              disabled={!currentTrack}
              className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-white text-black hover:scale-105 active:scale-95 flex items-center justify-center shadow-lg transition-transform disabled:opacity-40"
              title={isPlaying ? 'Pausar' : 'Reproducir'}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            <button
              onClick={onNext}
              disabled={!currentTrack}
              className="p-2 text-neutral-300 hover:text-white disabled:opacity-30 transition-colors"
              title="Siguiente canción"
            >
              <SkipForward className="w-5 h-5" />
            </button>

            <button
              onClick={onToggleRepeat}
              className={`p-2 rounded-full transition-colors ${
                repeatMode !== 'off' ? 'text-[#ff0033]' : 'text-neutral-400 hover:text-white'
              }`}
              title={`Repetir: ${repeatMode}`}
            >
              {repeatMode === 'one' ? <Repeat1 className="w-4 h-4" /> : <Repeat className="w-4 h-4" />}
            </button>
          </div>

          {/* Scrubber slider and timestamps */}
          <div className="w-full flex items-center gap-3">
            <span className="text-[11px] font-mono text-neutral-400 tabular-nums w-8 text-right">
              {formatTime(displayTime)}
            </span>

            <div className="relative flex-1 flex items-center">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={displayTime}
                onChange={handleSliderChange}
                onMouseDown={handleSliderStart}
                onTouchStart={handleSliderStart}
                onMouseUp={handleSliderEnd}
                onTouchEnd={handleSliderEnd}
                disabled={!currentTrack}
                className="w-full"
                aria-label="Progreso de reproducción"
              />
            </div>

            <span className="text-[11px] font-mono text-neutral-400 tabular-nums w-8">
              {formatTime(duration)}
            </span>
          </div>
        </div>

        {/* Right Slot: Auxiliary controls (Miracast, Queue, Lyrics, Volume) */}
        <div className="flex items-center justify-end gap-2 md:gap-3 w-1/4 min-w-[180px]">
          {/* Miracast Casting Trigger */}
          <button
            onClick={onOpenMiracast}
            className="p-2 text-neutral-400 hover:text-[#ff0033] rounded-full hover:bg-white/5 transition-colors relative"
            title="Transmitir con Miracast / Smart TV"
          >
            <Tv className="w-4 h-4" />
          </button>

          {/* Lyrics Toggle */}
          <button
            onClick={onToggleLyrics}
            className={`p-2 rounded-full transition-colors ${
              isLyricsOpen ? 'text-[#ff0033] bg-white/5' : 'text-neutral-400 hover:text-white'
            }`}
            title="Letras y visualizador"
          >
            <FileMusic className="w-4 h-4" />
          </button>

          {/* Queue Toggle */}
          <button
            onClick={onToggleQueue}
            className={`p-2 rounded-full transition-colors ${
              isQueueOpen ? 'text-[#ff0033] bg-white/5' : 'text-neutral-400 hover:text-white'
            }`}
            title="Cola de reproducción"
          >
            <ListMusic className="w-4 h-4" />
          </button>

          {/* Volume Control */}
          <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-white/5">
            <button
              onClick={onToggleMute}
              className="text-neutral-400 hover:text-white transition-colors"
              title={isMuted ? 'Activar sonido' : 'Silenciar'}
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-neutral-500" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-20"
              aria-label="Volumen"
            />
          </div>

          {/* Full Screen Mode */}
          <button
            onClick={onOpenFullScreen}
            className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-white/5 transition-colors"
            title="Modo pantalla completa"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
