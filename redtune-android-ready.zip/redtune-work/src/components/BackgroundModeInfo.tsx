import React, { useState } from 'react';
import { Volume2, Smartphone, Shield, Radio, Check, X } from 'lucide-react';
import { requestScreenWakeLock, releaseScreenWakeLock, enableBackgroundAudioEngine } from '../services/mediaSession';

interface BackgroundModeInfoProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BackgroundModeInfo: React.FC<BackgroundModeInfoProps> = ({ isOpen, onClose }) => {
  const [isWakeLockActive, setIsWakeLockActive] = useState(true);
  const [wakeLockMsg, setWakeLockMsg] = useState('Modo segundo plano y pantalla siempre activa encendidos');

  if (!isOpen) return null;

  const toggleWakeLock = async () => {
    if (isWakeLockActive) {
      releaseScreenWakeLock();
      setIsWakeLockActive(false);
      setWakeLockMsg('Bloqueo de pantalla desactivado. La pantalla podrá suspenderse según la configuración de tu sistema.');
    } else {
      enableBackgroundAudioEngine();
      const ok = await requestScreenWakeLock();
      setIsWakeLockActive(true);
      setWakeLockMsg(ok ? 'Pantalla y audio en segundo plano protegidos correctamente.' : 'Audio en segundo plano activo.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="w-full max-w-lg bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-2xl relative"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ff0033]/20 text-[#ff0033] flex items-center justify-center">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Música en Segundo Plano</h2>
              <p className="text-xs text-neutral-400">Escucha sin interrupciones con la pantalla bloqueada o en otras apps</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-xs text-neutral-300">
          {/* Active Status banner */}
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <div>
                <p className="font-semibold text-emerald-300">Motor de fondo activo</p>
                <p className="text-[11px] text-emerald-400/80">{wakeLockMsg}</p>
              </div>
            </div>
            <button
              onClick={toggleWakeLock}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                isWakeLockActive
                  ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                  : 'bg-white/10 text-white hover:bg-white/15'
              }`}
            >
              {isWakeLockActive ? 'Activo' : 'Activar'}
            </button>
          </div>

          {/* Pillars of background playback */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <Smartphone className="w-4 h-4 text-[#ff0033]" />
                <span>MediaSession API</span>
              </div>
              <p className="text-neutral-400 leading-relaxed text-[11px]">
                Controla la música desde la pantalla de bloqueo de tu teléfono, el centro de notificaciones o los controles de tu coche por Bluetooth.
              </p>
            </div>

            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <Volume2 className="w-4 h-4 text-[#ff0033]" />
                <span>Portador de Audio Web</span>
              </div>
              <p className="text-neutral-400 leading-relaxed text-[11px]">
                Mantiene el hilo de audio del navegador despierto para evitar que el sistema operativo congele la pestaña cuando cambias de aplicación.
              </p>
            </div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-[11px] text-neutral-400">
              <span className="font-semibold text-white">Recomendación para móviles: </span>
              Puedes apagar la pantalla o minimizar el navegador; la música continuará reproduciéndose en segundo plano fluidamente.
            </div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-white/5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-white/10 hover:bg-white/15 text-white font-medium rounded-xl text-xs transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
