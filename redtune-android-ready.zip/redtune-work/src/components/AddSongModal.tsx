import React, { useState } from 'react';
import { X, Youtube, Plus, Music, Check } from 'lucide-react';
import { Playlist, Track } from '../types/music';

interface AddSongModalProps {
  isOpen: boolean;
  onClose: () => void;
  playlists: Playlist[];
  defaultPlaylistId?: string;
  onAddSong: (song: Omit<Track, 'id'>, targetPlaylistId?: string) => void;
}

export function extractYouTubeId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  
  // Direct 11-char ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  // URLs: youtube.com/watch?v=... or music.youtube.com/watch?v=...
  const watchMatch = trimmed.match(/(?:v=|vi=|\/v\/|\/videos\/|\/embed\/|\/watch\?v=|\/watch\?.+&v=)([a-zA-Z0-9_-]{11})/);
  if (watchMatch && watchMatch[1]) {
    return watchMatch[1];
  }

  // Short URL: youtu.be/...
  const shortMatch = trimmed.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
  if (shortMatch && shortMatch[1]) {
    return shortMatch[1];
  }

  return null;
}

export const AddSongModal: React.FC<AddSongModalProps> = ({
  isOpen,
  onClose,
  playlists,
  defaultPlaylistId,
  onAddSong
}) => {
  const [urlOrId, setUrlOrId] = useState('');
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [album, setAlbum] = useState('');
  const [genre, setGenre] = useState('Pop / Alternativo');
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string>(
    defaultPlaylistId || (playlists[0]?.id || '')
  );
  const [detectedId, setDetectedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleUrlChange = (value: string) => {
    setUrlOrId(value);
    const parsed = extractYouTubeId(value);
    setDetectedId(parsed);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalYoutubeId = detectedId || extractYouTubeId(urlOrId);
    if (!finalYoutubeId) return;

    const finalTitle = title.trim() || `YouTube Track (${finalYoutubeId})`;
    const finalArtist = artist.trim() || 'Artista Desconocido';
    const finalAlbum = album.trim() || 'Sencillo YouTube';
    const thumbnail = `https://img.youtube.com/vi/${finalYoutubeId}/hqdefault.jpg`;

    onAddSong(
      {
        youtubeId: finalYoutubeId,
        title: finalTitle,
        artist: finalArtist,
        album: finalAlbum,
        duration: 210, // approximate default
        thumbnail,
        genre,
        isLiked: false,
        addedAt: Date.now()
      },
      selectedPlaylistId || undefined
    );

    // Reset and close
    setUrlOrId('');
    setTitle('');
    setArtist('');
    setAlbum('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="w-full max-w-md bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-2xl relative"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/20 text-[#ff0033] flex items-center justify-center">
              <Youtube className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Añadir Canción de YouTube</h2>
              <p className="text-xs text-neutral-400">Pega un enlace o ID para reproducir y guardar</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Enlace de YouTube o ID del video *
            </label>
            <input
              type="text"
              required
              value={urlOrId}
              onChange={(e) => handleUrlChange(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=... o jfKfPfyJRdk"
              className="w-full px-3.5 py-2.5 bg-neutral-900 border border-white/10 rounded-xl text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#ff0033] transition-colors"
            />
            {detectedId ? (
              <div className="flex items-center gap-1.5 mt-1.5 text-xs text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>ID detectado: {detectedId}</span>
              </div>
            ) : urlOrId.length > 5 ? (
              <p className="text-xs text-amber-400 mt-1">
                Asegúrate de pegar una URL válida o el código de 11 caracteres.
              </p>
            ) : null}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Título de la canción
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Nombre de la pista"
                className="w-full px-3 py-2 bg-neutral-900 border border-white/10 rounded-xl text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-[#ff0033] transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Artista
              </label>
              <input
                type="text"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                placeholder="Nombre del artista"
                className="w-full px-3 py-2 bg-neutral-900 border border-white/10 rounded-xl text-white placeholder-neutral-500 text-xs focus:outline-none focus:border-[#ff0033] transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Añadir a Lista de Reproducción
            </label>
            <select
              value={selectedPlaylistId}
              onChange={(e) => setSelectedPlaylistId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-neutral-900 border border-white/10 rounded-xl text-white text-xs focus:outline-none focus:border-[#ff0033] transition-colors"
            >
              <option value="">Solo biblioteca general</option>
              {playlists.map((pl) => (
                <option key={pl.id} value={pl.id}>
                  {pl.title} ({pl.trackIds.length} canciones)
                </option>
              ))}
            </select>
          </div>

          {detectedId && (
            <div className="p-3 bg-white/5 rounded-xl flex items-center gap-3 border border-white/5">
              <img
                src={`https://img.youtube.com/vi/${detectedId}/hqdefault.jpg`}
                alt="Miniatura"
                className="w-16 h-10 object-cover rounded-md"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="text-xs text-neutral-400">
                <span className="text-white font-medium">Miniatura de YouTube lista</span>
                <p>Se integrará a tu catálogo de música</p>
              </div>
            </div>
          )}

          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-300 hover:text-white transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!detectedId}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#ff0033] hover:bg-[#e6002e] rounded-xl shadow-lg shadow-[#ff0033]/20 transition-all active:scale-95 disabled:opacity-40"
            >
              Guardar Canción
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
