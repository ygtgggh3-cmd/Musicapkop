import React, { useState } from 'react';
import { 
  Play, 
  Search, 
  Plus, 
  Heart, 
  FolderPlus, 
  Download, 
  Upload, 
  Radio, 
  Sparkles, 
  Music,
  Tv,
  ListMusic
} from 'lucide-react';
import { ActiveNavTab, Playlist, Track } from '../types/music';

interface MainContentProps {
  activeTab: ActiveNavTab;
  tracks: Track[];
  playlists: Playlist[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onSelectTrack: (track: Track) => void;
  onSelectPlaylist: (playlistId: string) => void;
  onPlayPlaylist: (playlist: Playlist) => void;
  onToggleLike: (trackId: string) => void;
  onOpenCreatePlaylist: () => void;
  onOpenAddSong: () => void;
  onOpenMiracast: () => void;
  onOpenBackgroundInfo: () => void;
  onImportLibrary: (jsonText: string) => void;
}

export const MainContent: React.FC<MainContentProps> = ({
  activeTab,
  tracks,
  playlists,
  currentTrack,
  isPlaying,
  onSelectTrack,
  onSelectPlaylist,
  onPlayPlaylist,
  onToggleLike,
  onOpenCreatePlaylist,
  onOpenAddSong,
  onOpenMiracast,
  onOpenBackgroundInfo,
  onImportLibrary
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [librarySubTab, setLibrarySubTab] = useState<'playlists' | 'songs' | 'liked'>('playlists');

  const genres = ['all', 'Lo-Fi / Chill', 'Synthwave / Retro', 'Acústico / Instrumental', 'Electrónica / Minimal', 'Rock Clásico', 'Latino / Pop'];

  const filteredTracks = tracks.filter((t) => {
    const matchesSearch = 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.album.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'all' || t.genre.toLowerCase().includes(selectedGenre.toLowerCase());
    return matchesSearch && matchesGenre;
  });

  const likedTracks = tracks.filter((t) => t.isLiked);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onImportLibrary(content);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex-1 overflow-y-auto pb-32">
      {/* Top Search & Action Bar */}
      <div className="sticky top-0 z-20 bg-[#030303]/90 backdrop-blur-md px-6 py-4 border-b border-white/5 flex items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar canciones, artistas, álbumes o géneros..."
            className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/5 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-white/20 transition-colors"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAddSong}
            className="px-3 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 text-[#ff0033]" />
            <span>Pega URL YouTube</span>
          </button>

          <button
            onClick={onOpenMiracast}
            className="p-2 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-[#ff0033] rounded-xl transition-colors"
            title="Conectar Miracast"
          >
            <Tv className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-6 space-y-8">
        {/* Genre Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {genres.map((g) => (
            <button
              key={g}
              onClick={() => setSelectedGenre(g)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedGenre === g
                  ? 'bg-white text-black font-semibold'
                  : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {g === 'all' ? 'Todos los géneros' : g}
            </button>
          ))}
        </div>

        {/* VIEW: HOME */}
        {activeTab === 'home' && (
          <>
            {/* Quick Hero Banner */}
            <div className="relative overflow-hidden rounded-3xl p-6 md:p-8 bg-gradient-to-r from-neutral-900 via-[#181818] to-neutral-900 border border-white/5 shadow-xl">
              <div className="max-w-xl relative z-10">
                <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2">
                  <span>RedTune Web Client</span>
                  <span aria-hidden="true">·</span>
                  <span>Audio en Segundo Plano & Miracast</span>
                </div>
                <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
                  Toda tu música organizada a tu manera
                </h1>
                <p className="text-xs md:text-sm text-neutral-400 mt-2 leading-relaxed">
                  Crea listas personales, escucha sin cortes al apagar la pantalla y proyecta en alta fidelidad a cualquier televisor con Miracast.
                </p>
                <div className="flex items-center gap-3 mt-4">
                  <button
                    onClick={() => {
                      if (playlists[0]) onPlayPlaylist(playlists[0]);
                    }}
                    className="px-5 py-2.5 bg-[#ff0033] hover:bg-[#e6002e] text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg shadow-[#ff0033]/25 transition-all active:scale-95"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Reproducir Favoritos</span>
                  </button>

                  <button
                    onClick={onOpenBackgroundInfo}
                    className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-medium flex items-center gap-2 transition-colors"
                  >
                    <Radio className="w-4 h-4 text-emerald-400" />
                    <span>Segundo Plano</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Playlists Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-white tracking-tight">Tus Listas de Reproducción</h2>
                  <p className="text-xs text-neutral-400">Colecciones creadas para cada momento</p>
                </div>
                <button
                  onClick={onOpenCreatePlaylist}
                  className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 font-medium transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Crear lista</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {playlists.map((pl) => (
                  <div
                    key={pl.id}
                    onClick={() => onSelectPlaylist(pl.id)}
                    className="group bg-[#0e0e0e] hover:bg-[#141414] border border-white/5 hover:border-white/10 p-3.5 rounded-2xl cursor-pointer transition-all hover:scale-[1.01]"
                  >
                    <div className="relative aspect-square rounded-xl overflow-hidden bg-neutral-900 mb-3 shadow-md">
                      {pl.coverUrl ? (
                        <img
                          src={pl.coverUrl}
                          alt={pl.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-neutral-600">
                          <Music className="w-10 h-10" />
                        </div>
                      )}
                      {/* Hover play button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onPlayPlaylist(pl);
                        }}
                        className="absolute bottom-2.5 right-2.5 w-10 h-10 rounded-full bg-[#ff0033] text-white flex items-center justify-center opacity-0 group-hover:opacity-100 shadow-xl transition-all hover:scale-110"
                        title="Reproducir lista"
                      >
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      </button>
                    </div>

                    <h3 className="text-xs font-bold text-white truncate group-hover:text-[#ff0033] transition-colors">
                      {pl.title}
                    </h3>
                    <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 mt-1">
                      <span>{pl.isFavorites ? 'Colección' : 'Lista'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{pl.trackIds.length} canciones</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Popular Tracks Grid */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-bold text-white tracking-tight">Pistas Recomendadas</h2>
                  <p className="text-xs text-neutral-400">Selección con streaming estéreo y letras</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {filteredTracks.map((track) => {
                  const isCurrent = currentTrack?.id === track.id;
                  return (
                    <div
                      key={track.id}
                      onClick={() => onSelectTrack(track)}
                      className={`group flex items-center gap-3 p-2.5 rounded-xl border border-transparent transition-all cursor-pointer ${
                        isCurrent
                          ? 'bg-white/10 border-white/10 text-white'
                          : 'hover:bg-white/5 text-neutral-300'
                      }`}
                    >
                      <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 shadow-sm">
                        <img
                          src={track.thumbnail}
                          alt={track.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Play className="w-4 h-4 text-white fill-current ml-0.5" />
                        </div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-bold truncate ${isCurrent ? 'text-[#ff0033]' : 'text-white'}`}>
                          {track.title}
                        </p>
                        <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 truncate mt-0.5">
                          <span>{track.artist}</span>
                          <span aria-hidden="true">·</span>
                          <span>{track.genre}</span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleLike(track.id);
                        }}
                        className={`p-2 transition-colors ${
                          track.isLiked ? 'text-[#ff0033]' : 'text-neutral-500 hover:text-white'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${track.isLiked ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* VIEW: EXPLORE */}
        {activeTab === 'explore' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Explorar Música & Tendencias</h1>
              <p className="text-xs text-neutral-400">Descubre grabaciones acústicas, synthwave y géneros de todo el mundo</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTracks.map((track) => (
                <div
                  key={track.id}
                  onClick={() => onSelectTrack(track)}
                  className="group bg-[#0e0e0e] hover:bg-[#141414] border border-white/5 hover:border-white/10 p-3.5 rounded-2xl cursor-pointer transition-all"
                >
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-neutral-900 mb-3 shadow-md">
                    <img
                      src={track.thumbnail}
                      alt={track.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <div className="w-10 h-10 rounded-full bg-[#ff0033] text-white flex items-center justify-center shadow-lg">
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      </div>
                    </div>
                  </div>

                  <h3 className="text-xs font-bold text-white truncate">{track.title}</h3>
                  <div className="flex items-center gap-1 text-[11px] text-neutral-400 mt-1">
                    <span>{track.artist}</span>
                    <span aria-hidden="true">·</span>
                    <span>{track.genre}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIEW: LIBRARY */}
        {activeTab === 'library' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Tu Biblioteca Personal</h1>
                <p className="text-xs text-neutral-400">Organiza tus listas, temas favoritos y archivos respaldados</p>
              </div>

              {/* Import / Export & Create actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenCreatePlaylist}
                  className="px-3 py-2 bg-[#ff0033] hover:bg-[#e6002e] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nueva Lista</span>
                </button>

                <label className="px-3 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Importar JSON</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-2 border-b border-white/5 pb-2">
              <button
                onClick={() => setLibrarySubTab('playlists')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  librarySubTab === 'playlists' ? 'bg-white/10 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Listas ({playlists.length})
              </button>
              <button
                onClick={() => setLibrarySubTab('liked')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  librarySubTab === 'liked' ? 'bg-white/10 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Me Gusta ({likedTracks.length})
              </button>
              <button
                onClick={() => setLibrarySubTab('songs')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  librarySubTab === 'songs' ? 'bg-white/10 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Todas las canciones ({tracks.length})
              </button>
            </div>

            {/* Sub Tab Content */}
            {librarySubTab === 'playlists' && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {playlists.map((pl) => (
                  <div
                    key={pl.id}
                    onClick={() => onSelectPlaylist(pl.id)}
                    className="group bg-[#0e0e0e] hover:bg-[#141414] border border-white/5 hover:border-white/10 p-3.5 rounded-2xl cursor-pointer transition-all"
                  >
                    <div className="relative aspect-square rounded-xl overflow-hidden bg-neutral-900 mb-3 shadow-md">
                      <img
                        src={pl.coverUrl}
                        alt={pl.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <h3 className="text-xs font-bold text-white truncate">{pl.title}</h3>
                    <p className="text-[11px] text-neutral-400 mt-0.5">{pl.trackIds.length} canciones</p>
                  </div>
                ))}
              </div>
            )}

            {librarySubTab === 'liked' && (
              <div className="space-y-1">
                {likedTracks.length === 0 ? (
                  <div className="text-center py-12 text-neutral-500 text-xs">
                    No tienes canciones marcadas con corazón aún.
                  </div>
                ) : (
                  likedTracks.map((track, i) => (
                    <div
                      key={track.id}
                      onClick={() => onSelectTrack(track)}
                      className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/5 cursor-pointer text-xs"
                    >
                      <span className="font-mono text-neutral-500 w-6">{i + 1}</span>
                      <img src={track.thumbnail} alt={track.title} className="w-10 h-10 rounded-lg object-cover" />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-white truncate">{track.title}</p>
                        <p className="text-neutral-400 text-[11px] truncate">{track.artist}</p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleLike(track.id);
                        }}
                        className="text-[#ff0033] p-2"
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}

            {librarySubTab === 'songs' && (
              <div className="space-y-1">
                {tracks.map((track, i) => (
                  <div
                    key={track.id}
                    onClick={() => onSelectTrack(track)}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/5 cursor-pointer text-xs"
                  >
                    <span className="font-mono text-neutral-500 w-6">{i + 1}</span>
                    <img src={track.thumbnail} alt={track.title} className="w-10 h-10 rounded-lg object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-white truncate">{track.title}</p>
                      <p className="text-neutral-400 text-[11px] truncate">{track.artist} · {track.album}</p>
                    </div>
                    <span className="text-neutral-500 text-[11px]">{track.genre}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
