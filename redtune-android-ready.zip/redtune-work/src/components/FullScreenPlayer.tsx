import React from 'react';
import { 
  ChevronDown, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Repeat1, 
  Heart, 
  Tv, 
  Radio
} from 'lucide-react';
import { Track, RepeatMode } from '../types/music';
import { LyricsVisualizer } from './LyricsVisualizer';

interface FullScreenPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  repeatMode: RepeatMode;
  isShuffled: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (seconds: number) => void;
  onToggleRepeat: () => void;
  onToggleShuffle: () => void;
  onToggleLike: (trackId: string) => void;
  onOpenMiracast: () => void;
  onOpenBackgroundInfo: () => void;
}

export const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({
  isOpen,
  onClose,
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  repeatMode,
  isShuffled,
  onPlayPause,
  onNext,
  onPrevious,
  onSeek,
  onToggleRepeat,
  onToggleShuffle,
  onToggleLike,
  onOpenMiracast,
  onOpenBackgroundInfo
}) => {
  if (!isOpen || !currentTrack) return null;

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050505] text-white flex flex-col justify-between overflow-hidden select-none">
      {/* Dynamic blurred backdrop from cover */}
      <div 
        className="absolute inset-0 opacity-25 filter blur-[120px] pointer-events-none transform scale-125 transition-all duration-700"
        style={{
          backgroundImage: `url(${currentTrack.thumbnail})`,
          backgroundPosition: 'center',
          backgroundSize: 'cover'
        }}
      />

      {/* Top Bar */}
      <div className="relative z-10 px-6 py-4 flex items-center justify-between border-b border-white/5">
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
          title="Minimizar reproductor"
        >
          <ChevronDown className="w-6 h-6" />
        </button>

        <div className="text-center">
          <p className="text-xs font-semibold text-neutral-400">REPRODUCIENDO DESDE REDTUNE</p>
          <p className="text-xs font-medium text-white truncate max-w-xs">{currentTrack.album}</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Miracast Quick Cast */}
          <button
            onClick={onOpenMiracast}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-[#ff0033] transition-colors"
            title="Transmitir con Miracast"
          >
            <Tv className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Body: Split Column (Album Art + Visualizer / Lyrics) */}
      <div className="relative z-10 flex-1 max-w-6xl mx-auto w-full px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center overflow-y-auto">
        {/* Left Column: Big Cover Artwork */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-3xl overflow-hidden shadow-2xl border border-white/10 bg-neutral-900 group">
            <img
              src={currentTrack.thumbnail}
              alt={currentTrack.title}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Background mode badge button */}
          <button
            onClick={onOpenBackgroundInfo}
            className="mt-6 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/5 text-xs text-neutral-300 transition-colors"
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Música en segundo plano activa</span>
          </button>
        </div>

        {/* Right Column: Lyrics & Audio Visualizer */}
        <div className="lg:col-span-7 h-[420px] flex flex-col">
          <LyricsVisualizer
            track={currentTrack}
            currentTime={currentTime}
            duration={duration}
            isPlaying={isPlaying}
          />
        </div>
      </div>

      {/* Bottom Controls Area */}
      <div className="relative z-10 max-w-4xl mx-auto w-full px-6 pb-10 pt-4">
        {/* Track Title and Like Button */}
        <div className="flex items-center justify-between mb-4">
          <div className="min-w-0">
            <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight truncate">
              {currentTrack.title}
            </h2>
            <p className="text-sm text-neutral-400 truncate mt-1">
              {currentTrack.artist}
            </p>
          </div>

          <button
            onClick={() => onToggleLike(currentTrack.id)}
            className={`p-3 rounded-full transition-colors ${
              currentTrack.isLiked ? 'text-[#ff0033]' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Heart className={`w-6 h-6 ${currentTrack.isLiked ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Scrubber */}
        <div className="space-y-1.5">
          <input
            type="range"
            min={0}
            max={duration || 100}
            value={currentTime}
            onChange={(e) => onSeek(parseFloat(e.target.value))}
            className="w-full"
            aria-label="Barra de progreso"
          />
          <div className="flex justify-between text-xs font-mono text-neutral-400 tabular-nums">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-center gap-8 mt-4">
          <button
            onClick={onToggleShuffle}
            className={`p-3 rounded-full transition-colors ${
              isShuffled ? 'text-[#ff0033]' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Shuffle className="w-5 h-5" />
          </button>

          <button
            onClick={onPrevious}
            className="p-3 text-neutral-300 hover:text-white transition-colors"
          >
            <SkipBack className="w-7 h-7" />
          </button>

          <button
            onClick={onPlayPause}
            className="w-16 h-16 rounded-full bg-white text-black hover:scale-105 active:scale-95 flex items-center justify-center shadow-2xl transition-transform"
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 fill-current" />
            ) : (
              <Play className="w-8 h-8 fill-current ml-1" />
            )}
          </button>

          <button
            onClick={onNext}
            className="p-3 text-neutral-300 hover:text-white transition-colors"
          >
            <SkipForward className="w-7 h-7" />
          </button>

          <button
            onClick={onToggleRepeat}
            className={`p-3 rounded-full transition-colors ${
              repeatMode !== 'off' ? 'text-[#ff0033]' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {repeatMode === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
