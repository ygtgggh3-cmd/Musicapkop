import React, { useState, useEffect } from 'react';
import { Tv, Cast, ExternalLink, X, Check, Monitor, Radio, HelpCircle, ShieldCheck } from 'lucide-react';
import { 
  isPresentationApiSupported, 
  startNativePresentation, 
  openExternalDisplayWindow,
  sendMiracastMessage
} from '../services/presentationService';
import { Track } from '../types/music';

interface MiracastModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
}

export const MiracastModal: React.FC<MiracastModalProps> = ({
  isOpen,
  onClose,
  currentTrack,
  isPlaying,
  currentTime
}) => {
  const [isSupported, setIsSupported] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionSuccess, setConnectionSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'connect' | 'guide'>('connect');

  useEffect(() => {
    setIsSupported(isPresentationApiSupported());
  }, []);

  // Broadcast current state whenever track or playing state changes
  useEffect(() => {
    if (currentTrack) {
      sendMiracastMessage('TRACK_SYNC', {
        track: currentTrack,
        isPlaying,
        currentTime
      });
    }
  }, [currentTrack, isPlaying, currentTime]);

  if (!isOpen) return null;

  const handleNativeCast = async () => {
    setIsConnecting(true);
    setErrorMessage(null);
    try {
      const res = await startNativePresentation();
      if (res.success) {
        setConnectionSuccess(true);
      } else {
        setErrorMessage(res.error || 'No se pudo iniciar la transmisión.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error al conectar con la pantalla inalámbrica.');
    } finally {
      setIsConnecting(false);
    }
  };

  const handleOpenReceiver = () => {
    openExternalDisplayWindow();
    setConnectionSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="w-full max-w-lg bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="miracast-dialog-title"
      >
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#ff0033]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between pb-4 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-[#ff0033]">
              <Tv className="w-5 h-5" />
            </div>
            <div>
              <h2 id="miracast-dialog-title" className="text-lg font-bold text-white">
                Soporte Miracast & Pantalla Inalámbrica
              </h2>
              <p className="text-xs text-neutral-400">
                Transmite música, visuales y letras a tu Smart TV o monitor
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-2 my-4 p-1 bg-white/5 rounded-xl">
          <button
            onClick={() => setActiveTab('connect')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'connect'
                ? 'bg-white/10 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Conectar Dispositivo
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'guide'
                ? 'bg-white/10 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Guía de Configuración
          </button>
        </div>

        {activeTab === 'connect' ? (
          <div className="space-y-4">
            {/* Active track preview */}
            {currentTrack && (
              <div className="p-3 bg-white/5 rounded-xl flex items-center gap-3 border border-white/5">
                <img
                  src={currentTrack.thumbnail}
                  alt={currentTrack.title}
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{currentTrack.title}</p>
                  <p className="text-xs text-neutral-400 truncate">{currentTrack.artist}</p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-emerald-400">
                  <Radio className="w-4 h-4 animate-pulse" />
                  <span>Listo para proyectar</span>
                </div>
              </div>
            )}

            {/* Connection Actions */}
            <div className="space-y-3 pt-2">
              <button
                onClick={handleNativeCast}
                disabled={isConnecting}
                className="w-full h-12 rounded-xl bg-[#ff0033] hover:bg-[#e6002e] text-white font-medium text-sm flex items-center justify-center gap-2.5 transition-all shadow-lg shadow-[#ff0033]/20 active:scale-[0.98] disabled:opacity-50"
              >
                <Cast className="w-5 h-5" />
                <span>
                  {isConnecting ? 'Buscando receptores Miracast...' : 'Transmitir por Miracast / Presentation'}
                </span>
              </button>

              <button
                onClick={handleOpenReceiver}
                className="w-full h-12 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium text-sm flex items-center justify-center gap-2.5 transition-all active:scale-[0.98]"
              >
                <Monitor className="w-5 h-5 text-neutral-300" />
                <span>Abrir Modo TV en Segunda Pantalla</span>
                <ExternalLink className="w-4 h-4 text-neutral-400" />
              </button>
            </div>

            {connectionSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Transmisión activa sincronizada. El reproductor y la pantalla remota están vinculados.</span>
              </div>
            )}

            {errorMessage && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 text-xs">
                <p>{errorMessage}</p>
                <p className="mt-1 text-neutral-400">
                  Tip: También puedes usar la opción &quot;Abrir Modo TV en Segunda Pantalla&quot; o presionar Win+K en tu equipo.
                </p>
              </div>
            )}

            {/* Hardware compatibility note */}
            <div className="p-3 bg-neutral-900/60 rounded-xl border border-white/5 text-xs text-neutral-400 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-[#ff0033] shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-neutral-300">Compatibilidad Universal</p>
                <p className="mt-0.5 leading-relaxed">
                  Compatible con receptores Wi-Fi Direct Miracast, Smart TVs (Samsung, LG, Sony, TCL), adaptadores HDMI inalámbricos y Windows Wireless Display.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3.5 text-xs text-neutral-300 max-h-72 overflow-y-auto pr-1">
            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <span>1. En tu computadora (Windows 10/11)</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Presiona la combinación de teclas <kbd className="px-1.5 py-0.5 bg-black/40 border border-white/10 rounded font-mono text-neutral-200">Win</kbd> + <kbd className="px-1.5 py-0.5 bg-black/40 border border-white/10 rounded font-mono text-neutral-200">K</kbd> en tu teclado para abrir el menú &quot;Transmitir&quot;. Selecciona tu televisor o dongle Miracast de la lista.
              </p>
            </div>

            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <span>2. En tu móvil o tablet (Android)</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Desliza la barra de notificaciones y pulsa en <strong className="text-white">Smart View</strong>, <strong className="text-white">Transmitir pantalla</strong> o <strong className="text-white">Pantalla inalámbrica</strong>. Elige tu televisor.
              </p>
            </div>

            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <span>3. En tu Smart TV / Proyector</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Asegúrate de que la televisión esté encendida en la misma red Wi-Fi o con la función &quot;Screen Mirroring / Miracast&quot; habilitada en los ajustes de entradas.
              </p>
            </div>

            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-2 font-semibold text-white mb-1">
                <HelpCircle className="w-4 h-4 text-[#ff0033]" />
                <span>¿Por qué RedTune con Miracast?</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                A diferencia de aplicaciones estándar, RedTune sincroniza automáticamente la pista activa, carátula en alta definición, ecualizador en vivo y letras a pantalla completa optimizada para salas de estar.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
