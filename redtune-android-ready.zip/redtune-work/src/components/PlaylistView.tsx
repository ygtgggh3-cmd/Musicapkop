import React, { useState } from 'react';
import { 
  Play, 
  Shuffle, 
  Plus, 
  Edit3, 
  Trash2, 
  Download, 
  Heart, 
  ChevronUp, 
  ChevronDown, 
  MoreVertical,
  Search,
  Music,
  Clock
} from 'lucide-react';
import { Playlist, Track } from '../types/music';

interface PlaylistViewProps {
  playlist: Playlist;
  tracks: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayPlaylist: (playlist: Playlist, startIndex?: number) => void;
  onShufflePlaylist: (playlist: Playlist) => void;
  onSelectTrack: (track: Track) => void;
  onToggleLike: (trackId: string) => void;
  onRemoveTrackFromPlaylist: (playlistId: string, trackId: string) => void;
  onReorderTrack: (playlistId: string, fromIndex: number, toIndex: number) => void;
  onOpenAddSong: (playlistId: string) => void;
  onEditPlaylist: (playlist: Playlist) => void;
  onDeletePlaylist: (playlistId: string) => void;
  allPlaylists: Playlist[];
  onAddTrackToOtherPlaylist: (targetPlaylistId: string, trackId: string) => void;
}

export const PlaylistView: React.FC<PlaylistViewProps> = ({
  playlist,
  tracks,
  currentTrack,
  isPlaying,
  onPlayPlaylist,
  onShufflePlaylist,
  onSelectTrack,
  onToggleLike,
  onRemoveTrackFromPlaylist,
  onReorderTrack,
  onOpenAddSong,
  onEditPlaylist,
  onDeletePlaylist,
  allPlaylists,
  onAddTrackToOtherPlaylist
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [activeMenuTrackId, setActiveMenuTrackId] = useState<string | null>(null);

  // Filter songs based on search query
  const filteredTracks = tracks.filter(t => 
    t.title.toLowerCase().includes(filterQuery.toLowerCase()) ||
    t.artist.toLowerCase().includes(filterQuery.toLowerCase()) ||
    t.album.toLowerCase().includes(filterQuery.toLowerCase())
  );

  const totalDurationSeconds = tracks.reduce((sum, t) => sum + (t.duration || 0), 0);
  const totalMinutes = Math.floor(totalDurationSeconds / 60);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(playlist, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `redtune_playlist_${playlist.title.replace(/\s+/g, '_').toLowerCase()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="flex-1 overflow-y-auto pb-32">
      {/* Header Banner */}
      <div 
        className="relative p-6 md:p-8 rounded-b-3xl border-b border-white/5 transition-colors"
        style={{
          background: `linear-gradient(180deg, ${playlist.accentColor || '#ff0033'}25 0%, #030303 100%)`
        }}
      >
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center md:items-end gap-6 md:gap-8">
          {/* Cover Art */}
          <div className="w-44 h-44 md:w-52 md:h-52 rounded-2xl overflow-hidden shadow-2xl shrink-0 border border-white/10 bg-neutral-900 group relative">
            {playlist.coverUrl ? (
              <img
                src={playlist.coverUrl}
                alt={playlist.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-neutral-600 bg-neutral-900">
                <Music className="w-16 h-16" />
              </div>
            )}
            <div 
              onClick={() => onPlayPlaylist(playlist)}
              className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity"
            >
              <div className="w-14 h-14 rounded-full bg-[#ff0033] text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                <Play className="w-6 h-6 fill-current ml-0.5" />
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0 text-center md:text-left">
            {/* Zero-Pill Unboxed Metadata */}
            <div className="flex items-center justify-center md:justify-start gap-2 text-xs text-neutral-400 mb-2">
              <span>{playlist.isFavorites ? 'Colección Favorita' : 'Lista Personal'}</span>
              <span aria-hidden="true">·</span>
              <span>{tracks.length} canciones</span>
              <span aria-hidden="true">·</span>
              <span>{totalMinutes} min</span>
            </div>

            <h1 className="text-2xl md:text-4xl font-extrabold text-white tracking-tight line-clamp-2">
              {playlist.title}
            </h1>

            <p className="text-sm text-neutral-400 mt-2 max-w-2xl line-clamp-2 leading-relaxed">
              {playlist.description || 'Sin descripción personalizada.'}
            </p>

            {/* Actions Bar */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mt-6">
              <button
                onClick={() => onPlayPlaylist(playlist)}
                disabled={tracks.length === 0}
                className="px-6 py-2.5 bg-[#ff0033] hover:bg-[#e6002e] text-white rounded-xl font-semibold text-xs flex items-center gap-2 shadow-lg shadow-[#ff0033]/25 transition-all active:scale-95 disabled:opacity-40"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Reproducir Todo</span>
              </button>

              <button
                onClick={() => onShufflePlaylist(playlist)}
                disabled={tracks.length === 0}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-medium text-xs flex items-center gap-2 transition-colors disabled:opacity-40"
              >
                <Shuffle className="w-4 h-4" />
                <span>Aleatorio</span>
              </button>

              <button
                onClick={() => onOpenAddSong(playlist.id)}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-medium text-xs flex items-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Canción</span>
              </button>

              {!playlist.isSystem && (
                <>
                  <button
                    onClick={() => onEditPlaylist(playlist)}
                    className="p-2.5 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white rounded-xl transition-colors"
                    title="Editar detalles de la lista"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDeletePlaylist(playlist.id)}
                    className="p-2.5 bg-white/5 hover:bg-red-500/20 text-neutral-300 hover:text-red-400 rounded-xl transition-colors"
                    title="Eliminar lista"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}

              <button
                onClick={handleExportJson}
                className="p-2.5 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white rounded-xl transition-colors"
                title="Exportar lista como JSON"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Track List Section */}
      <div className="max-w-6xl mx-auto px-4 md:px-8 mt-6">
        {/* Search filter within playlist */}
        <div className="flex items-center justify-between mb-4">
          <div className="relative w-full max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Buscar en esta lista..."
              className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/5 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-white/20 transition-colors"
            />
          </div>

          <span className="text-xs text-neutral-500 tabular-nums">
            {filteredTracks.length} de {tracks.length} temas
          </span>
        </div>

        {/* Songs Table Header */}
        <div className="grid grid-cols-12 gap-4 px-4 py-2 text-xs font-semibold text-neutral-500 border-b border-white/5">
          <div className="col-span-1 text-center">#</div>
          <div className="col-span-6 md:col-span-5">Título</div>
          <div className="hidden md:block col-span-3">Álbum</div>
          <div className="col-span-5 md:col-span-3 flex items-center justify-end gap-6 pr-2">
            <span className="hidden sm:inline">Ordenar</span>
            <Clock className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Songs Rows */}
        {filteredTracks.length === 0 ? (
          <div className="text-center py-16 text-neutral-500">
            <Music className="w-12 h-12 mx-auto mb-3 opacity-30 text-white" />
            <p className="text-sm font-medium">Esta lista está vacía</p>
            <p className="text-xs text-neutral-600 mt-1">Haz clic en &quot;Añadir Canción&quot; para sumar tus temas favoritos de YouTube.</p>
          </div>
        ) : (
          <div className="space-y-1 mt-2">
            {filteredTracks.map((track, index) => {
              const isCurrent = currentTrack?.id === track.id;
              const originalIndex = tracks.findIndex(t => t.id === track.id);

              return (
                <div
                  key={track.id}
                  className={`group grid grid-cols-12 gap-4 items-center px-4 py-2.5 rounded-xl transition-all ${
                    isCurrent
                      ? 'bg-white/10 text-white'
                      : 'hover:bg-white/5 text-neutral-300'
                  }`}
                >
                  {/* Track Index or Play Icon */}
                  <div className="col-span-1 flex items-center justify-center">
                    <button
                      onClick={() => onSelectTrack(track)}
                      className="w-7 h-7 flex items-center justify-center text-xs font-mono text-neutral-400 group-hover:text-white"
                    >
                      {isCurrent && isPlaying ? (
                        <span className="w-3 h-3 bg-[#ff0033] rounded-full animate-pulse" />
                      ) : (
                        <span className="group-hover:hidden tabular-nums">{index + 1}</span>
                      )}
                      <Play className="w-3.5 h-3.5 fill-current hidden group-hover:block ml-0.5" />
                    </button>
                  </div>

                  {/* Thumbnail & Title/Artist */}
                  <div className="col-span-6 md:col-span-5 flex items-center gap-3 min-w-0">
                    <img
                      src={track.thumbnail}
                      alt={track.title}
                      className="w-10 h-10 rounded-lg object-cover shrink-0 shadow-sm"
                    />
                    <div className="min-w-0 cursor-pointer" onClick={() => onSelectTrack(track)}>
                      <p className={`text-xs font-semibold truncate ${isCurrent ? 'text-[#ff0033]' : 'text-white'}`}>
                        {track.title}
                      </p>
                      <p className="text-[11px] text-neutral-400 truncate">
                        {track.artist}
                      </p>
                    </div>
                  </div>

                  {/* Album */}
                  <div className="hidden md:block col-span-3 text-xs text-neutral-400 truncate">
                    {track.album}
                  </div>

                  {/* Actions & Duration */}
                  <div className="col-span-5 md:col-span-3 flex items-center justify-end gap-2 sm:gap-3 text-xs">
                    {/* Reorder controls (up/down) */}
                    <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onReorderTrack(playlist.id, originalIndex, originalIndex - 1)}
                        disabled={originalIndex === 0}
                        className="p-1 hover:text-white disabled:opacity-20"
                        title="Subir de posición"
                      >
                        <ChevronUp className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onReorderTrack(playlist.id, originalIndex, originalIndex + 1)}
                        disabled={originalIndex === tracks.length - 1}
                        className="p-1 hover:text-white disabled:opacity-20"
                        title="Bajar de posición"
                      >
                        <ChevronDown className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Like button */}
                    <button
                      onClick={() => onToggleLike(track.id)}
                      className={`p-1.5 transition-colors ${
                        track.isLiked ? 'text-[#ff0033]' : 'text-neutral-500 hover:text-neutral-300'
                      }`}
                      title={track.isLiked ? 'Quitar de Me Gusta' : 'Guardar en Me Gusta'}
                    >
                      <Heart className={`w-4 h-4 ${track.isLiked ? 'fill-current' : ''}`} />
                    </button>

                    {/* Duration */}
                    <span className="text-neutral-400 tabular-nums w-10 text-right">
                      {formatTime(track.duration)}
                    </span>

                    {/* Options Menu Dropdown */}
                    <div className="relative">
                      <button
                        onClick={() => setActiveMenuTrackId(activeMenuTrackId === track.id ? null : track.id)}
                        className="p-1 text-neutral-500 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
                        title="Opciones"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>

                      {activeMenuTrackId === track.id && (
                        <div className="absolute right-0 top-full mt-1 w-48 bg-[#181818] border border-white/10 rounded-xl shadow-2xl py-1.5 z-30 text-xs">
                          <button
                            onClick={() => {
                              onRemoveTrackFromPlaylist(playlist.id, track.id);
                              setActiveMenuTrackId(null);
                            }}
                            className="w-full text-left px-3 py-2 text-red-400 hover:bg-white/5 flex items-center gap-2"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Quitar de esta lista</span>
                          </button>

                          <div className="border-t border-white/5 my-1" />
                          <div className="px-3 py-1 text-[10px] uppercase font-bold text-neutral-500">
                            Añadir a otra lista:
                          </div>
                          {allPlaylists
                            .filter(p => p.id !== playlist.id)
                            .map(targetPl => (
                              <button
                                key={targetPl.id}
                                onClick={() => {
                                  onAddTrackToOtherPlaylist(targetPl.id, track.id);
                                  setActiveMenuTrackId(null);
                                }}
                                className="w-full text-left px-3 py-1.5 text-neutral-300 hover:text-white hover:bg-white/5 truncate"
                              >
                                {targetPl.title}
                              </button>
                            ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
