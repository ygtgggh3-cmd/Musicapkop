import React, { useEffect, useState, useRef } from 'react';
import { Track } from '../types/music';
import { Tv, Play, Pause, SkipForward, SkipBack, Maximize, Minimize } from 'lucide-react';
import { subscribeToMiracastChannel } from '../services/presentationService';

interface MiracastScreenProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onPlayPause?: () => void;
  onNext?: () => void;
  onPrevious?: () => void;
  onSeek?: (seconds: number) => void;
}

export const MiracastScreen: React.FC<MiracastScreenProps> = ({
  currentTrack: propTrack,
  isPlaying: propIsPlaying,
  currentTime: propCurrentTime,
  duration: propDuration,
  onPlayPause,
  onNext,
  onPrevious
}) => {
  const [track, setTrack] = useState<Track | null>(propTrack);
  const [isPlaying, setIsPlaying] = useState<boolean>(propIsPlaying);
  const [currentTime, setCurrentTime] = useState<number>(propCurrentTime);
  const [duration, setDuration] = useState<number>(propDuration);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Sync with props
  useEffect(() => {
    if (propTrack) setTrack(propTrack);
    setIsPlaying(propIsPlaying);
    setCurrentTime(propCurrentTime);
    setDuration(propDuration);
  }, [propTrack, propIsPlaying, propCurrentTime, propDuration]);

  // Also listen for BroadcastChannel events if opened in separate popup / TV window
  useEffect(() => {
    const unsubscribe = subscribeToMiracastChannel((event) => {
      if (event.type === 'TRACK_SYNC' && event.payload) {
        if (event.payload.track) setTrack(event.payload.track);
        if (typeof event.payload.isPlaying === 'boolean') setIsPlaying(event.payload.isPlaying);
        if (typeof event.payload.currentTime === 'number') setCurrentTime(event.payload.currentTime);
      }
    });
    return () => unsubscribe();
  }, []);

  // TV Audio visualizer animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;
    const bars = 64;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const w = canvas.width;
      const h = canvas.height;
      const barWidth = w / bars - 4;

      phase += isPlaying ? 0.06 : 0.008;

      for (let i = 0; i < bars; i++) {
        const factor = Math.sin(i * 0.15 + phase) * Math.cos(i * 0.1 - phase * 0.5);
        const barHeight = isPlaying
          ? Math.max(8, Math.abs(factor) * (h * 0.85) + Math.sin(phase * 3 + i) * 15)
          : 6;

        const x = i * (barWidth + 4);
        const y = h - barHeight;

        const grad = ctx.createLinearGradient(0, h, 0, 0);
        grad.addColorStop(0, '#ff0033');
        grad.addColorStop(0.5, '#ff4d00');
        grad.addColorStop(1, '#ffaa00');

        ctx.fillStyle = isPlaying ? grad : 'rgba(255, 255, 255, 0.15)';
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, 4);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const lyrics = track?.lyrics || [
    'Transmitiendo audio inalámbrico mediante Miracast / Wi-Fi Direct',
    'Disfruta la experiencia envolvente en tu pantalla grande',
    'Calidad de sonido pura optimizada para tu sala'
  ];

  const progressRatio = duration > 0 ? currentTime / duration : 0;
  const activeLineIndex = Math.min(
    lyrics.length - 1,
    Math.floor(progressRatio * lyrics.length)
  );

  return (
    <div className="relative w-full h-full bg-[#050505] text-white flex flex-col justify-between p-8 md:p-14 overflow-hidden select-none">
      {/* Dynamic Ambient Background Glow from Album Art */}
      <div 
        className="absolute inset-0 opacity-20 filter blur-[100px] pointer-events-none transform scale-125 transition-all duration-1000"
        style={{
          backgroundImage: track?.thumbnail ? `url(${track.thumbnail})` : 'none',
          backgroundPosition: 'center',
          backgroundSize: 'cover'
        }}
      />

      {/* Top Bar: TV Cast status & Fullscreen button */}
      <div className="relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#ff0033]">
            <Tv className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold tracking-tight">RedTune TV</span>
              <span className="text-neutral-500">·</span>
              <span className="text-xs text-neutral-400">Modo Pantalla Grande Miracast</span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Sincronizado vía Wi-Fi Direct · 320 kbps High Fidelity Audio
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleFullscreen}
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
            title="Pantalla completa"
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Center Hero: Vinyl Cover + Track Info + Giant Lyrics */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center my-auto">
        {/* Left Column: Vinyl Record & Album Art */}
        <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left">
          <div className="relative group">
            {/* Spinning vinyl disc effect */}
            <div 
              className={`absolute -top-3 -right-6 w-56 h-56 md:w-80 md:h-80 rounded-full bg-neutral-900 border-4 border-neutral-800 shadow-2xl flex items-center justify-center transition-all duration-700 pointer-events-none ${
                isPlaying ? 'animate-[spin_12s_linear_infinite]' : ''
              }`}
            >
              {/* Vinyl grooves */}
              <div className="w-40 h-40 md:w-56 md:h-56 rounded-full border border-neutral-700/60 flex items-center justify-center">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border border-neutral-700/40 flex items-center justify-center">
                  <div className="w-10 h-10 md:w-14 md:h-14 rounded-full bg-[#ff0033]/80 border-2 border-white/20" />
                </div>
              </div>
            </div>

            {/* Album Cover Art */}
            <div className="relative z-10 w-56 h-56 md:w-80 md:h-80 rounded-2xl overflow-hidden shadow-2xl border border-white/10 bg-neutral-900">
              {track ? (
                <img
                  src={track.thumbnail}
                  alt={track.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-neutral-800 text-neutral-400">
                  Sin pista activa
                </div>
              )}
            </div>
          </div>

          {/* Track Details */}
          <div className="mt-8 max-w-md">
            <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white line-clamp-2">
              {track ? track.title : 'Reproducción en espera'}
            </h1>
            <p className="text-lg md:text-xl font-medium text-neutral-300 mt-2">
              {track ? track.artist : 'Selecciona una canción en RedTune'}
            </p>
            {track && (
              <p className="text-sm text-neutral-400 mt-1">
                {track.album} · {track.genre}
              </p>
            )}
          </div>
        </div>

        {/* Right Column: Giant Synced TV Lyrics */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6 lg:pl-8">
          <div className="text-xs uppercase tracking-widest text-[#ff0033] font-bold">
            Letras en Pantalla
          </div>
          <div className="space-y-6 max-h-[380px] overflow-hidden">
            {lyrics.map((line, idx) => {
              const isActive = idx === activeLineIndex;
              const isPast = idx < activeLineIndex;
              return (
                <p
                  key={idx}
                  className={`text-2xl md:text-4xl font-semibold transition-all duration-500 leading-snug ${
                    isActive
                      ? 'text-white scale-[1.03] origin-left font-bold'
                      : isPast
                      ? 'text-neutral-500 opacity-40'
                      : 'text-neutral-600 opacity-60'
                  }`}
                >
                  {line}
                </p>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom: High-Resolution Spectrum Visualizer & Quick Remote Controls */}
      <div className="relative z-10 w-full space-y-4">
        <canvas
          ref={canvasRef}
          width={1200}
          height={60}
          className="w-full h-12 md:h-16 rounded-xl"
        />

        <div className="flex items-center justify-between text-xs text-neutral-400 pt-2 border-t border-white/5">
          <div className="flex items-center gap-2">
            <span>Receptor Miracast / Pantalla TV</span>
            <span>·</span>
            <span>Controles remotos activos</span>
          </div>

          {/* Quick TV Control buttons */}
          <div className="flex items-center gap-4">
            <button
              onClick={onPrevious}
              className="p-2 hover:text-white transition-colors"
              title="Anterior"
            >
              <SkipBack className="w-5 h-5" />
            </button>
            <button
              onClick={onPlayPause}
              className="w-10 h-10 rounded-full bg-white text-black hover:scale-105 flex items-center justify-center transition-all"
              title={isPlaying ? 'Pausar' : 'Reproducir'}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </button>
            <button
              onClick={onNext}
              className="p-2 hover:text-white transition-colors"
              title="Siguiente"
            >
              <SkipForward className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
