import React from 'react';
import { X, Play, Trash2, ListMusic, Music } from 'lucide-react';
import { Track } from '../types/music';

interface QueueDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  queue: Track[];
  currentTrack: Track | null;
  isPlaying: boolean;
  onSelectTrack: (track: Track) => void;
  onRemoveFromQueue: (trackId: string) => void;
  onClearQueue: () => void;
}

export const QueueDrawer: React.FC<QueueDrawerProps> = ({
  isOpen,
  onClose,
  queue,
  currentTrack,
  isPlaying,
  onSelectTrack,
  onRemoveFromQueue,
  onClearQueue
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-40 w-full max-w-sm bg-[#111111] border-l border-white/10 shadow-2xl flex flex-col backdrop-blur-xl">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <ListMusic className="w-5 h-5 text-[#ff0033]" />
          <h2 className="text-base font-bold text-white">Cola de Reproducción</h2>
          <span className="text-xs text-neutral-400">({queue.length})</span>
        </div>
        <div className="flex items-center gap-1">
          {queue.length > 0 && (
            <button
              onClick={onClearQueue}
              className="p-1.5 text-xs text-neutral-400 hover:text-red-400 rounded-lg hover:bg-white/5 transition-colors"
              title="Vaciar cola"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Currently Playing Card */}
        {currentTrack && (
          <div>
            <div className="text-[11px] uppercase tracking-wider text-[#ff0033] font-bold px-2 mb-2">
              En Reproducción
            </div>
            <div className="flex items-center gap-3 p-2.5 bg-[#ff0033]/10 border border-[#ff0033]/20 rounded-xl">
              <img
                src={currentTrack.thumbnail}
                alt={currentTrack.title}
                className="w-12 h-12 rounded-lg object-cover shadow-sm"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-white truncate">{currentTrack.title}</p>
                <p className="text-[11px] text-neutral-400 truncate">{currentTrack.artist}</p>
              </div>
              <div className="text-[#ff0033] text-xs font-medium px-2 py-1">
                {isPlaying ? 'Sonando' : 'Pausado'}
              </div>
            </div>
          </div>
        )}

        {/* Up Next List */}
        <div>
          <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-bold px-2 mb-2">
            A Continuación
          </div>
          {queue.length === 0 ? (
            <div className="text-center py-8 text-neutral-500 text-xs">
              <Music className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p>No hay canciones siguientes en la cola.</p>
              <p className="mt-1 text-neutral-600">Añade pistas desde cualquier lista.</p>
            </div>
          ) : (
            <div className="space-y-1">
              {queue.map((track, idx) => {
                const isCurrent = currentTrack?.id === track.id;
                return (
                  <div
                    key={`${track.id}_${idx}`}
                    className={`group flex items-center gap-3 p-2 rounded-xl transition-colors ${
                      isCurrent ? 'bg-white/10 text-white' : 'hover:bg-white/5 text-neutral-300'
                    }`}
                  >
                    <button
                      onClick={() => onSelectTrack(track)}
                      className="w-10 h-10 rounded-lg overflow-hidden relative shrink-0"
                    >
                      <img
                        src={track.thumbnail}
                        alt={track.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <Play className="w-4 h-4 text-white fill-current" />
                      </div>
                    </button>

                    <div 
                      onClick={() => onSelectTrack(track)}
                      className="flex-1 min-w-0 cursor-pointer"
                    >
                      <p className="text-xs font-medium text-white truncate">{track.title}</p>
                      <p className="text-[11px] text-neutral-400 truncate">{track.artist}</p>
                    </div>

                    <button
                      onClick={() => onRemoveFromQueue(track.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 text-neutral-500 hover:text-red-400 transition-opacity"
                      title="Quitar de la cola"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
