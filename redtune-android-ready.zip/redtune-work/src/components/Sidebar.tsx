import React from 'react';
import { 
  Home, 
  Compass, 
  Library, 
  Tv, 
  Plus, 
  Heart, 
  Radio, 
  FileMusic, 
  Music2,
  FolderPlus
} from 'lucide-react';
import { ActiveNavTab, Playlist } from '../types/music';

interface SidebarProps {
  activeTab: ActiveNavTab;
  onSelectTab: (tab: ActiveNavTab) => void;
  playlists: Playlist[];
  selectedPlaylistId: string | null;
  onSelectPlaylist: (playlistId: string) => void;
  onOpenCreatePlaylist: () => void;
  onOpenBackgroundInfo: () => void;
  onOpenAddSong: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  playlists,
  selectedPlaylistId,
  onSelectPlaylist,
  onOpenCreatePlaylist,
  onOpenBackgroundInfo,
  onOpenAddSong
}) => {
  return (
    <aside className="hidden md:flex flex-col w-64 bg-[#0a0a0a] border-r border-white/5 h-full shrink-0 select-none">
      {/* Brand Zone: 1-line text element with RedTune symbol */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-white/5">
        <div className="w-8 h-8 rounded-full bg-[#ff0033] flex items-center justify-center text-white shadow-lg shadow-[#ff0033]/25">
          <Music2 className="w-4 h-4 fill-current" />
        </div>
        <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
          RedTune
        </span>
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1">
        <button
          onClick={() => {
            onSelectTab('home');
          }}
          className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'home' && selectedPlaylistId === null
              ? 'bg-white/10 text-white shadow-sm'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Inicio</span>
        </button>

        <button
          onClick={() => {
            onSelectTab('explore');
          }}
          className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'explore' && selectedPlaylistId === null
              ? 'bg-white/10 text-white shadow-sm'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Explorar</span>
        </button>

        <button
          onClick={() => {
            onSelectTab('library');
          }}
          className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'library' && selectedPlaylistId === null
              ? 'bg-white/10 text-white shadow-sm'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Library className="w-4 h-4" />
          <span>Tu Biblioteca</span>
        </button>

        <button
          onClick={() => {
            onSelectTab('miracast');
          }}
          className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'miracast'
              ? 'bg-[#ff0033]/15 text-[#ff0033] shadow-sm'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Tv className="w-4 h-4 text-[#ff0033]" />
          <span>Miracast TV</span>
        </button>

        <button
          onClick={() => {
            onSelectTab('lyrics');
          }}
          className={`w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'lyrics'
              ? 'bg-white/10 text-white shadow-sm'
              : 'text-neutral-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileMusic className="w-4 h-4" />
          <span>Letras & Visual</span>
        </button>
      </nav>

      {/* Playlist Section Divider */}
      <div className="px-5 pt-4 pb-2 flex items-center justify-between text-xs text-neutral-400">
        <span className="font-semibold text-neutral-300">Tus Listas</span>
        <div className="flex items-center gap-1">
          <button
            onClick={onOpenAddSong}
            className="p-1 hover:text-white text-neutral-400 transition-colors"
            title="Añadir canción por URL"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenCreatePlaylist}
            className="p-1 hover:text-white text-neutral-400 transition-colors"
            title="Crear nueva lista"
          >
            <FolderPlus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Playlists List */}
      <div className="flex-1 overflow-y-auto px-3 py-1 space-y-1">
        {playlists.map((pl) => {
          const isSelected = selectedPlaylistId === pl.id;
          return (
            <button
              key={pl.id}
              onClick={() => onSelectPlaylist(pl.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium text-left transition-colors truncate ${
                isSelected
                  ? 'bg-white/10 text-white font-semibold'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {pl.isFavorites ? (
                <div className="w-7 h-7 rounded-lg bg-red-500/20 text-[#ff0033] flex items-center justify-center shrink-0">
                  <Heart className="w-3.5 h-3.5 fill-current" />
                </div>
              ) : (
                <div 
                  className="w-7 h-7 rounded-lg overflow-hidden shrink-0 bg-neutral-800 flex items-center justify-center"
                  style={{ backgroundColor: `${pl.accentColor || '#ff0033'}25` }}
                >
                  {pl.coverUrl ? (
                    <img src={pl.coverUrl} alt={pl.title} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[10px] text-white">#</span>
                  )}
                </div>
              )}
              <div className="truncate flex-1">
                <p className="truncate text-white">{pl.title}</p>
                <p className="text-[10px] text-neutral-500">{pl.trackIds.length} canciones</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Background Playback Mode Status Widget */}
      <div className="p-3 border-t border-white/5 m-2 bg-white/5 rounded-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-[11px] font-semibold text-neutral-200">Segundo Plano</span>
          </div>
          <button
            onClick={onOpenBackgroundInfo}
            className="text-[10px] text-[#ff0033] hover:underline font-medium"
          >
            Ajustes
          </button>
        </div>
        <p className="text-[10px] text-neutral-400 mt-1 leading-tight">
          Audio persistente con pantalla bloqueada y control MediaSession.
        </p>
      </div>
    </aside>
  );
};
