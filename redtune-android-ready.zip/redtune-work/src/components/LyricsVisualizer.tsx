import React, { useEffect, useRef } from 'react';
import { Track } from '../types/music';

interface LyricsVisualizerProps {
  track: Track | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
}

export const LyricsVisualizer: React.FC<LyricsVisualizerProps> = ({
  track,
  currentTime,
  duration,
  isPlaying
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Audio frequency simulation visualizer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;
    const barCount = 36;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const barWidth = (width / barCount) - 3;

      phase += isPlaying ? 0.08 : 0.01;

      for (let i = 0; i < barCount; i++) {
        // Dynamic simulated harmonics
        const freqMultiplier = Math.sin(i * 0.25 + phase) * Math.cos(i * 0.15 - phase * 0.8);
        const dynamicHeight = isPlaying
          ? Math.max(6, Math.abs(freqMultiplier) * (height * 0.75) + Math.sin(phase * 2 + i) * 12)
          : 6;

        const x = i * (barWidth + 3);
        const y = height - dynamicHeight;

        // Gradient from bright crimson to subtle orange
        const gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, '#ff0033');
        gradient.addColorStop(1, '#ff6600');

        ctx.fillStyle = isPlaying ? gradient : 'rgba(255, 255, 255, 0.2)';
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, dynamicHeight, 3);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying]);

  if (!track) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-neutral-500 py-12">
        <p className="text-sm">Selecciona una pista para ver las letras y el visualizador</p>
      </div>
    );
  }

  const lyrics = track.lyrics || [
    'Disfrutando de la música instrumental...',
    'Déjate llevar por los acordes y el ritmo.',
    'Sonido transmitido en alta calidad.',
    'Controla la reproducción desde la barra inferior.'
  ];

  // Calculate current active lyric line based on playback progress
  const progressRatio = duration > 0 ? currentTime / duration : 0;
  const activeLineIndex = Math.min(
    lyrics.length - 1,
    Math.floor(progressRatio * lyrics.length)
  );

  return (
    <div className="flex flex-col h-full space-y-6">
      {/* Top canvas visualizer */}
      <div className="w-full bg-neutral-900/60 rounded-2xl p-4 border border-white/5 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-3 text-xs text-neutral-400">
          <span>Visualizador de Frecuencias</span>
          <span className="tabular-nums">
            {isPlaying ? 'Transmitiendo audio estéreo 320 kbps' : 'En pausa'}
          </span>
        </div>
        <canvas
          ref={canvasRef}
          width={480}
          height={64}
          className="w-full h-16 rounded-lg"
        />
      </div>

      {/* Synchronized lyrics container */}
      <div className="flex-1 overflow-y-auto space-y-5 px-2 py-4">
        {lyrics.map((line, index) => {
          const isActive = index === activeLineIndex;
          const isPast = index < activeLineIndex;

          return (
            <p
              key={index}
              className={`transition-all duration-300 text-lg md:text-xl font-medium leading-relaxed ${
                isActive
                  ? 'text-white scale-[1.02] origin-left font-semibold'
                  : isPast
                  ? 'text-neutral-500 opacity-60'
                  : 'text-neutral-600'
              }`}
            >
              {line}
            </p>
          );
        })}
      </div>
    </div>
  );
};
