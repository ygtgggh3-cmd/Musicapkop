import React, { useState } from 'react';
import { X, Music2, Palette } from 'lucide-react';
import { COVER_LOFI, COVER_SYNTHWAVE, COVER_ACOUSTIC, COVER_ELECTRONIC } from '../data/initialTracks';

interface CreatePlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (title: string, description: string, accentColor: string, coverUrl: string) => void;
  initialTitle?: string;
  initialDescription?: string;
  initialColor?: string;
  isEditing?: boolean;
}

const PRESET_COVERS = [
  { url: COVER_LOFI, label: 'Tokyo Rain Lo-Fi' },
  { url: COVER_SYNTHWAVE, label: 'Synthwave Night' },
  { url: COVER_ACOUSTIC, label: 'Acústico Orgánico' },
  { url: COVER_ELECTRONIC, label: 'Obsidian Minimal' }
];

const ACCENT_COLORS = [
  '#FF0033', // Crimson Red (Default YouTube Music)
  '#8B5CF6', // Purple
  '#3B82F6', // Blue
  '#10B981', // Emerald
  '#F59E0B', // Amber
  '#EC4899'  // Pink
];

export const CreatePlaylistModal: React.FC<CreatePlaylistModalProps> = ({
  isOpen,
  onClose,
  onCreate,
  initialTitle = '',
  initialDescription = '',
  initialColor = '#FF0033',
  isEditing = false
}) => {
  const [title, setTitle] = useState(initialTitle);
  const [description, setDescription] = useState(initialDescription);
  const [accentColor, setAccentColor] = useState(initialColor);
  const [selectedCover, setSelectedCover] = useState(PRESET_COVERS[0].url);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onCreate(title.trim(), description.trim(), accentColor, selectedCover);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="w-full max-w-md bg-[#121212] border border-white/10 rounded-2xl p-6 shadow-2xl relative"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-4 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div 
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${accentColor}20`, color: accentColor }}
            >
              <Music2 className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-white">
              {isEditing ? 'Editar Lista de Reproducción' : 'Nueva Lista Personal'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Título de la lista *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej. Mis Favoritas para Viajar, Noche Chill..."
              className="w-full px-3.5 py-2.5 bg-neutral-900 border border-white/10 rounded-xl text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#ff0033] transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Descripción opcional
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Añade notas o temática de esta colección..."
              className="w-full px-3.5 py-2.5 bg-neutral-900 border border-white/10 rounded-xl text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-[#ff0033] transition-colors resize-none"
            />
          </div>

          {/* Accent Color Selection */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-neutral-300 mb-2">
              <Palette className="w-3.5 h-3.5" />
              <span>Color distintivo</span>
            </label>
            <div className="flex items-center gap-2.5">
              {ACCENT_COLORS.map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => setAccentColor(col)}
                  className={`w-7 h-7 rounded-full transition-transform ${
                    accentColor === col ? 'scale-125 ring-2 ring-white ring-offset-2 ring-offset-[#121212]' : 'hover:scale-110 opacity-80'
                  }`}
                  style={{ backgroundColor: col }}
                  aria-label={`Color ${col}`}
                />
              ))}
            </div>
          </div>

          {/* Preset Cover Selector */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-2">
              Carátula de portada
            </label>
            <div className="grid grid-cols-4 gap-2">
              {PRESET_COVERS.map((preset) => (
                <button
                  key={preset.url}
                  type="button"
                  onClick={() => setSelectedCover(preset.url)}
                  className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all ${
                    selectedCover === preset.url
                      ? 'border-[#ff0033] scale-105 shadow-md'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={preset.url}
                    alt={preset.label}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-300 hover:text-white transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#ff0033] hover:bg-[#e6002e] rounded-xl shadow-lg shadow-[#ff0033]/20 transition-all active:scale-95"
            >
              {isEditing ? 'Guardar Cambios' : 'Crear Lista'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
