/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Home, 
  Compass, 
  Library, 
  Tv, 
  FileMusic
} from 'lucide-react';
import { Track, Playlist, RepeatMode, ActiveNavTab } from './types/music';
import { 
  loadStoredTracks, 
  saveStoredTracks, 
  loadStoredPlaylists, 
  saveStoredPlaylists, 
  loadPlayerSettings, 
  savePlayerSettings,
  saveRecentlyPlayedId 
} from './services/storage';
import { ytController } from './services/youtubeController';
import { 
  updateMediaSession, 
  enableBackgroundAudioEngine, 
  requestScreenWakeLock, 
  resumeBackgroundAudioEngine 
} from './services/mediaSession';
import { sendMiracastMessage } from './services/presentationService';

import { Sidebar } from './components/Sidebar';
import { PlayerBar } from './components/PlayerBar';
import { MainContent } from './components/MainContent';
import { PlaylistView } from './components/PlaylistView';
import { FullScreenPlayer } from './components/FullScreenPlayer';
import { MiracastModal } from './components/MiracastModal';
import { MiracastScreen } from './components/MiracastScreen';
import { CreatePlaylistModal } from './components/CreatePlaylistModal';
import { AddSongModal } from './components/AddSongModal';
import { QueueDrawer } from './components/QueueDrawer';
import { BackgroundModeInfo } from './components/BackgroundModeInfo';
import { LyricsVisualizer } from './components/LyricsVisualizer';

export default function App() {
  // Check if opened as dedicated Miracast receiver screen
  const [isMiracastReceiverMode, setIsMiracastReceiverMode] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('mode') === 'miracast-display' || window.location.hash === '#miracast-screen') {
        setIsMiracastReceiverMode(true);
      }
    }
  }, []);

  // Primary Data State
  const [tracks, setTracks] = useState<Track[]>(() => loadStoredTracks());
  const [playlists, setPlaylists] = useState<Playlist[]>(() => loadStoredPlaylists());
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveNavTab>('home');

  // Player State
  const [currentTrack, setCurrentTrack] = useState<Track | null>(() => tracks[0] || null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(() => tracks[0]?.duration || 215);
  
  const savedSettings = useRef(loadPlayerSettings());
  const [volume, setVolume] = useState<number>(savedSettings.current.volume);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>(savedSettings.current.repeatMode);
  const [isShuffled, setIsShuffled] = useState<boolean>(savedSettings.current.isShuffled);

  // Queue State
  const [queue, setQueue] = useState<Track[]>(() => tracks.slice(1));

  // UI Drawer / Modal States
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isFullScreenOpen, setIsFullScreenOpen] = useState(false);
  const [isMiracastModalOpen, setIsMiracastModalOpen] = useState(false);
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
  const [editingPlaylist, setEditingPlaylist] = useState<Playlist | null>(null);
  const [isAddSongOpen, setIsAddSongOpen] = useState(false);
  const [targetPlaylistForAdd, setTargetPlaylistForAdd] = useState<string | undefined>(undefined);
  const [isBackgroundInfoOpen, setIsBackgroundInfoOpen] = useState(false);

  // Initialize background audio engine and YouTube Player Mount
  useEffect(() => {
    enableBackgroundAudioEngine();
    requestScreenWakeLock();

    // Register YouTube controller
    ytController.registerContainer(
      'youtube-hidden-player',
      {
        onReady: () => {
          ytController.setVolume(volume * 100);
        },
        onStateChange: (state) => {
          if (state === 1) {
            setIsPlaying(true);
          } else if (state === 2) {
            setIsPlaying(false);
          }
        },
        onTimeUpdate: (curr, dur) => {
          setCurrentTime(curr);
          if (dur && dur > 0) {
            setDuration(dur);
          }
        },
        onEnded: () => {
          handleTrackEnded();
        },
        onError: (errCode) => {
          console.warn('YouTube embedded error code:', errCode);
          // If track is restricted from embedding, automatically move to next track
          handlePlayNext();
        }
      },
      currentTrack?.youtubeId || tracks[0]?.youtubeId || 'jfKfPfyJRdk'
    );

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        resumeBackgroundAudioEngine();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveStoredTracks(tracks);
  }, [tracks]);

  useEffect(() => {
    saveStoredPlaylists(playlists);
  }, [playlists]);

  useEffect(() => {
    savePlayerSettings({
      volume,
      repeatMode,
      isShuffled,
      backgroundKeepAlive: true
    });
  }, [volume, repeatMode, isShuffled]);

  // Synchronize MediaSession (Lockscreen / Bluetooth / Car)
  useEffect(() => {
    updateMediaSession(currentTrack, isPlaying, {
      onPlay: () => handlePlay(),
      onPause: () => handlePause(),
      onNext: () => handlePlayNext(),
      onPrevious: () => handlePlayPrevious(),
      onSeek: (target) => handleSeek(target)
    });

    // Broadcast to Miracast second screen
    if (currentTrack) {
      sendMiracastMessage('TRACK_SYNC', {
        track: currentTrack,
        isPlaying,
        currentTime,
        duration
      });
    }
  }, [currentTrack, isPlaying, currentTime, duration]);

  // Playback Control Handlers
  const handlePlay = useCallback(() => {
    if (!currentTrack) {
      if (tracks.length > 0) {
        handleSelectTrack(tracks[0]);
      }
      return;
    }
    resumeBackgroundAudioEngine();
    ytController.play();
    setIsPlaying(true);
  }, [currentTrack, tracks]);

  const handlePause = useCallback(() => {
    ytController.pause();
    setIsPlaying(false);
  }, []);

  const handlePlayPause = useCallback(() => {
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  }, [isPlaying, handlePlay, handlePause]);

  const handleSelectTrack = useCallback((track: Track, newQueue?: Track[]) => {
    setCurrentTrack(track);
    setCurrentTime(0);
    setDuration(track.duration || 215);
    setIsPlaying(true);
    saveRecentlyPlayedId(track.id);

    // Update queue if provided
    if (newQueue) {
      setQueue(newQueue.filter(t => t.id !== track.id));
    }

    resumeBackgroundAudioEngine();
    ytController.loadAndPlay(track.youtubeId);
  }, []);

  const handlePlayNext = useCallback(() => {
    if (queue.length > 0) {
      const next = queue[0];
      const remaining = queue.slice(1);
      // If repeat all, push current to end of queue
      if (repeatMode === 'all' && currentTrack) {
        remaining.push(currentTrack);
      }
      setQueue(remaining);
      handleSelectTrack(next);
    } else if (repeatMode === 'all' && currentTrack) {
      // Loop current track or pick first from library
      handleSelectTrack(tracks[0] || currentTrack);
    } else {
      setIsPlaying(false);
    }
  }, [queue, repeatMode, currentTrack, tracks, handleSelectTrack]);

  const handlePlayPrevious = useCallback(() => {
    if (currentTime > 4) {
      // If played more than 4 seconds, restart current track
      ytController.seekTo(0);
      setCurrentTime(0);
    } else {
      // Pick previous track from library
      const currentIndex = tracks.findIndex(t => t.id === currentTrack?.id);
      const prevIndex = currentIndex > 0 ? currentIndex - 1 : tracks.length - 1;
      if (tracks[prevIndex]) {
        handleSelectTrack(tracks[prevIndex]);
      }
    }
  }, [currentTime, tracks, currentTrack, handleSelectTrack]);

  const handleTrackEnded = useCallback(() => {
    if (repeatMode === 'one') {
      ytController.seekTo(0);
      ytController.play();
    } else {
      handlePlayNext();
    }
  }, [repeatMode, handlePlayNext]);

  const handleSeek = useCallback((seconds: number) => {
    setCurrentTime(seconds);
    ytController.seekTo(seconds);
  }, []);

  const handleVolumeChange = useCallback((newVol: number) => {
    setVolume(newVol);
    setIsMuted(newVol === 0);
    ytController.setVolume(newVol * 100);
  }, []);

  const handleToggleMute = useCallback(() => {
    if (isMuted) {
      setIsMuted(false);
      ytController.unMute();
      ytController.setVolume(volume * 100);
    } else {
      setIsMuted(true);
      ytController.mute();
    }
  }, [isMuted, volume]);

  const handleToggleRepeat = useCallback(() => {
    setRepeatMode(prev => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
  }, []);

  const handleToggleShuffle = useCallback(() => {
    setIsShuffled(prev => {
      const next = !prev;
      if (next && queue.length > 0) {
        // Shuffle existing queue
        const shuffled = [...queue].sort(() => Math.random() - 0.5);
        setQueue(shuffled);
      }
      return next;
    });
  }, [queue]);

  const handleToggleLike = useCallback((trackId: string) => {
    setTracks(prev => prev.map(t => {
      if (t.id === trackId) {
        return { ...t, isLiked: !t.isLiked };
      }
      return t;
    }));

    // Update system Favorites playlist
    setPlaylists(prev => prev.map(pl => {
      if (pl.isFavorites) {
        const hasTrack = pl.trackIds.includes(trackId);
        const updated = hasTrack
          ? pl.trackIds.filter(id => id !== trackId)
          : [...pl.trackIds, trackId];
        return { ...pl, trackIds: updated, updatedAt: Date.now() };
      }
      return pl;
    }));

    if (currentTrack && currentTrack.id === trackId) {
      setCurrentTrack(prev => prev ? { ...prev, isLiked: !prev.isLiked } : null);
    }
  }, [currentTrack]);

  // Playlist Management Handlers
  const handleCreateOrUpdatePlaylist = (title: string, description: string, accentColor: string, coverUrl: string) => {
    if (editingPlaylist) {
      // Update
      setPlaylists(prev => prev.map(pl => {
        if (pl.id === editingPlaylist.id) {
          return {
            ...pl,
            title,
            description,
            accentColor,
            coverUrl,
            updatedAt: Date.now()
          };
        }
        return pl;
      }));
      setEditingPlaylist(null);
    } else {
      // Create New
      const newPlaylist: Playlist = {
        id: `playlist_${Date.now()}`,
        title,
        description,
        coverUrl,
        accentColor,
        trackIds: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isSystem: false
      };
      setPlaylists(prev => [...prev, newPlaylist]);
      setSelectedPlaylistId(newPlaylist.id);
    }
  };

  const handleDeletePlaylist = (playlistId: string) => {
    setPlaylists(prev => prev.filter(pl => pl.id !== playlistId));
    if (selectedPlaylistId === playlistId) {
      setSelectedPlaylistId(null);
    }
  };

  const handlePlayPlaylist = (playlist: Playlist, startIndex = 0) => {
    const playlistTracks = playlist.trackIds
      .map(id => tracks.find(t => t.id === id))
      .filter((t): t is Track => !!t);

    if (playlistTracks.length === 0) return;

    const startTrack = playlistTracks[startIndex] || playlistTracks[0];
    const upNext = playlistTracks.slice(startIndex + 1);
    handleSelectTrack(startTrack, upNext);
  };

  const handleShufflePlaylist = (playlist: Playlist) => {
    const playlistTracks = playlist.trackIds
      .map(id => tracks.find(t => t.id === id))
      .filter((t): t is Track => !!t);

    if (playlistTracks.length === 0) return;
    const shuffled = [...playlistTracks].sort(() => Math.random() - 0.5);
    const startTrack = shuffled[0];
    const upNext = shuffled.slice(1);
    handleSelectTrack(startTrack, upNext);
  };

  const handleRemoveTrackFromPlaylist = (playlistId: string, trackId: string) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === playlistId) {
        return {
          ...pl,
          trackIds: pl.trackIds.filter(id => id !== trackId),
          updatedAt: Date.now()
        };
      }
      return pl;
    }));
  };

  const handleReorderTrack = (playlistId: string, fromIndex: number, toIndex: number) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === playlistId) {
        const list = [...pl.trackIds];
        if (toIndex < 0 || toIndex >= list.length) return pl;
        const [moved] = list.splice(fromIndex, 1);
        list.splice(toIndex, 0, moved);
        return {
          ...pl,
          trackIds: list,
          updatedAt: Date.now()
        };
      }
      return pl;
    }));
  };

  const handleAddTrackToOtherPlaylist = (targetPlaylistId: string, trackId: string) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === targetPlaylistId) {
        if (!pl.trackIds.includes(trackId)) {
          return {
            ...pl,
            trackIds: [...pl.trackIds, trackId],
            updatedAt: Date.now()
          };
        }
      }
      return pl;
    }));
  };

  const handleAddNewSong = (songData: Omit<Track, 'id'>, targetPlaylistId?: string) => {
    const newTrack: Track = {
      ...songData,
      id: `custom_track_${Date.now()}`
    };

    setTracks(prev => [newTrack, ...prev]);

    if (targetPlaylistId) {
      setPlaylists(prev => prev.map(pl => {
        if (pl.id === targetPlaylistId) {
          return {
            ...pl,
            trackIds: [newTrack.id, ...pl.trackIds],
            updatedAt: Date.now()
          };
        }
        return pl;
      }));
    }

    // Play immediately
    handleSelectTrack(newTrack);
  };

  const handleImportLibrary = (jsonText: string) => {
    try {
      const parsed = JSON.parse(jsonText);
      if (parsed.id && parsed.title && Array.isArray(parsed.trackIds)) {
        // Single playlist import
        const importedPl: Playlist = {
          ...parsed,
          id: `playlist_import_${Date.now()}`,
          isSystem: false
        };
        setPlaylists(prev => [...prev, importedPl]);
        setSelectedPlaylistId(importedPl.id);
      } else if (Array.isArray(parsed)) {
        // Array of playlists
        setPlaylists(parsed);
      }
    } catch (err) {
      console.error('Error importing library JSON:', err);
    }
  };

  // If in dedicated Miracast Display Receiver Mode
  if (isMiracastReceiverMode) {
    return (
      <MiracastScreen
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        onPlayPause={handlePlayPause}
        onNext={handlePlayNext}
        onPrevious={handlePlayPrevious}
      />
    );
  }

  // Active selected playlist object
  const currentPlaylist = selectedPlaylistId 
    ? playlists.find(p => p.id === selectedPlaylistId) || null 
    : null;

  const currentPlaylistTracks = currentPlaylist
    ? currentPlaylist.trackIds.map(id => tracks.find(t => t.id === id)).filter((t): t is Track => !!t)
    : [];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#030303] text-neutral-100 font-sans">
      {/* Hidden YouTube IFrame container for background audio playback */}
      <div 
        id="youtube-hidden-player"
        style={{
          position: 'fixed',
          top: -9999,
          left: -9999,
          width: 320,
          height: 240,
          pointerEvents: 'none',
          opacity: 0.001
        }}
        aria-hidden="true"
      />

      {/* Desktop Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setSelectedPlaylistId(null);
        }}
        playlists={playlists}
        selectedPlaylistId={selectedPlaylistId}
        onSelectPlaylist={(plId) => {
          setSelectedPlaylistId(plId);
        }}
        onOpenCreatePlaylist={() => {
          setEditingPlaylist(null);
          setIsCreatePlaylistOpen(true);
        }}
        onOpenBackgroundInfo={() => setIsBackgroundInfoOpen(true)}
        onOpenAddSong={() => {
          setTargetPlaylistForAdd(selectedPlaylistId || undefined);
          setIsAddSongOpen(true);
        }}
      />

      {/* Main View Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        {selectedPlaylistId && currentPlaylist ? (
          <PlaylistView
            playlist={currentPlaylist}
            tracks={currentPlaylistTracks}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onPlayPlaylist={handlePlayPlaylist}
            onShufflePlaylist={handleShufflePlaylist}
            onSelectTrack={handleSelectTrack}
            onToggleLike={handleToggleLike}
            onRemoveTrackFromPlaylist={handleRemoveTrackFromPlaylist}
            onReorderTrack={handleReorderTrack}
            onOpenAddSong={(plId) => {
              setTargetPlaylistForAdd(plId);
              setIsAddSongOpen(true);
            }}
            onEditPlaylist={(pl) => {
              setEditingPlaylist(pl);
              setIsCreatePlaylistOpen(true);
            }}
            onDeletePlaylist={handleDeletePlaylist}
            allPlaylists={playlists}
            onAddTrackToOtherPlaylist={handleAddTrackToOtherPlaylist}
          />
        ) : activeTab === 'miracast' ? (
          <MiracastScreen
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            onPlayPause={handlePlayPause}
            onNext={handlePlayNext}
            onPrevious={handlePlayPrevious}
          />
        ) : activeTab === 'lyrics' ? (
          <div className="flex-1 max-w-4xl mx-auto w-full p-6 md:p-8 overflow-y-auto pb-32">
            <h1 className="text-xl font-bold text-white mb-6">Letras & Visualizador en Vivo</h1>
            <LyricsVisualizer
              track={currentTrack}
              currentTime={currentTime}
              duration={duration}
              isPlaying={isPlaying}
            />
          </div>
        ) : (
          <MainContent
            activeTab={activeTab}
            tracks={tracks}
            playlists={playlists}
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            onSelectTrack={handleSelectTrack}
            onSelectPlaylist={(plId) => setSelectedPlaylistId(plId)}
            onPlayPlaylist={handlePlayPlaylist}
            onToggleLike={handleToggleLike}
            onOpenCreatePlaylist={() => {
              setEditingPlaylist(null);
              setIsCreatePlaylistOpen(true);
            }}
            onOpenAddSong={() => {
              setTargetPlaylistForAdd(undefined);
              setIsAddSongOpen(true);
            }}
            onOpenMiracast={() => setIsMiracastModalOpen(true)}
            onOpenBackgroundInfo={() => setIsBackgroundInfoOpen(true)}
            onImportLibrary={handleImportLibrary}
          />
        )}

        {/* Mobile Fixed Thumb Navigation Bar */}
        <div className="md:hidden fixed bottom-20 left-0 right-0 z-30 bg-[#0e0e0e]/95 border-t border-white/5 backdrop-blur-md grid grid-cols-5 items-center h-14 px-2">
          <button
            onClick={() => {
              setActiveTab('home');
              setSelectedPlaylistId(null);
            }}
            className={`min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium ${
              activeTab === 'home' && !selectedPlaylistId ? 'text-[#ff0033]' : 'text-neutral-400'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="mt-0.5">Inicio</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('explore');
              setSelectedPlaylistId(null);
            }}
            className={`min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium ${
              activeTab === 'explore' ? 'text-[#ff0033]' : 'text-neutral-400'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="mt-0.5">Explorar</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('library');
              setSelectedPlaylistId(null);
            }}
            className={`min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium ${
              activeTab === 'library' ? 'text-[#ff0033]' : 'text-neutral-400'
            }`}
          >
            <Library className="w-5 h-5" />
            <span className="mt-0.5">Biblioteca</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('miracast');
            }}
            className={`min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium ${
              activeTab === 'miracast' ? 'text-[#ff0033]' : 'text-neutral-400'
            }`}
          >
            <Tv className="w-5 h-5" />
            <span className="mt-0.5">Miracast</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('lyrics');
            }}
            className={`min-h-[44px] flex flex-col items-center justify-center text-[10px] font-medium ${
              activeTab === 'lyrics' ? 'text-[#ff0033]' : 'text-neutral-400'
            }`}
          >
            <FileMusic className="w-5 h-5" />
            <span className="mt-0.5">Letras</span>
          </button>
        </div>

        {/* Persistent Bottom Player Bar */}
        <PlayerBar
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          volume={volume}
          isMuted={isMuted}
          repeatMode={repeatMode}
          isShuffled={isShuffled}
          isQueueOpen={isQueueOpen}
          isLyricsOpen={isLyricsOpen}
          onPlayPause={handlePlayPause}
          onNext={handlePlayNext}
          onPrevious={handlePlayPrevious}
          onSeek={handleSeek}
          onVolumeChange={handleVolumeChange}
          onToggleMute={handleToggleMute}
          onToggleRepeat={handleToggleRepeat}
          onToggleShuffle={handleToggleShuffle}
          onToggleLike={handleToggleLike}
          onToggleQueue={() => setIsQueueOpen(prev => !prev)}
          onToggleLyrics={() => setIsLyricsOpen(prev => !prev)}
          onOpenMiracast={() => setIsMiracastModalOpen(true)}
          onOpenFullScreen={() => setIsFullScreenOpen(true)}
        />
      </main>

      {/* Floating Queue Drawer */}
      <QueueDrawer
        isOpen={isQueueOpen}
        onClose={() => setIsQueueOpen(false)}
        queue={queue}
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        onSelectTrack={(t) => handleSelectTrack(t)}
        onRemoveFromQueue={(id) => setQueue(prev => prev.filter(t => t.id !== id))}
        onClearQueue={() => setQueue([])}
      />

      {/* Immersive Cinema Full-Screen Player */}
      <FullScreenPlayer
        isOpen={isFullScreenOpen}
        onClose={() => setIsFullScreenOpen(false)}
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        repeatMode={repeatMode}
        isShuffled={isShuffled}
        onPlayPause={handlePlayPause}
        onNext={handlePlayNext}
        onPrevious={handlePlayPrevious}
        onSeek={handleSeek}
        onToggleRepeat={handleToggleRepeat}
        onToggleShuffle={handleToggleShuffle}
        onToggleLike={handleToggleLike}
        onOpenMiracast={() => {
          setIsFullScreenOpen(false);
          setIsMiracastModalOpen(true);
        }}
        onOpenBackgroundInfo={() => setIsBackgroundInfoOpen(true)}
      />

      {/* Miracast & Wireless Display Connection Modal */}
      <MiracastModal
        isOpen={isMiracastModalOpen}
        onClose={() => setIsMiracastModalOpen(false)}
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
      />

      {/* Create / Edit Playlist Modal */}
      <CreatePlaylistModal
        isOpen={isCreatePlaylistOpen}
        onClose={() => {
          setIsCreatePlaylistOpen(false);
          setEditingPlaylist(null);
        }}
        onCreate={handleCreateOrUpdatePlaylist}
        initialTitle={editingPlaylist?.title || ''}
        initialDescription={editingPlaylist?.description || ''}
        initialColor={editingPlaylist?.accentColor || '#FF0033'}
        isEditing={!!editingPlaylist}
      />

      {/* Add Song from YouTube URL Modal */}
      <AddSongModal
        isOpen={isAddSongOpen}
        onClose={() => setIsAddSongOpen(false)}
        playlists={playlists}
        defaultPlaylistId={targetPlaylistForAdd}
        onAddSong={handleAddNewSong}
      />

      {/* Background Playback & WakeLock Info Modal */}
      <BackgroundModeInfo
        isOpen={isBackgroundInfoOpen}
        onClose={() => setIsBackgroundInfoOpen(false)}
      />
    </div>
  );
}
