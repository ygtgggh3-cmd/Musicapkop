import { Track, Playlist } from '../types/music';

// Generated high-fidelity cover assets
export const COVER_LOFI = '/src/assets/images/ambient_lofi_artwork_1792616926519.jpg';
export const COVER_SYNTHWAVE = '/src/assets/images/synthwave_retro_artwork_1792616927256.jpg';
export const COVER_ACOUSTIC = '/src/assets/images/latin_acoustic_artwork_1792616928386.jpg';
export const COVER_ELECTRONIC = '/src/assets/images/electronic_pulse_artwork_1792616927958.jpg';

export const INITIAL_TRACKS: Track[] = [
  {
    id: 'track_1',
    youtubeId: 'jfKfPfyJRdk', // Lofi Girl Chill beats
    title: 'Tokyo Rain at Dusk',
    artist: 'Rainy Vinyl Records',
    album: 'Tokyo Rain - Chill Beats',
    duration: 215,
    thumbnail: COVER_LOFI,
    genre: 'Lo-Fi / Chill',
    lyrics: [
      'Gente caminando bajo los paraguas de neón',
      'El sonido de las gotas contra el asfalto de Shibuya',
      'Una taza de café caliente en el balcón',
      'Las luces se difuminan en la niebla nocturna',
      'Melodías suaves para calmar el pensamiento',
      'El tiempo se detiene en este rincón del mundo',
      'Respira lento, déjate llevar por el ritmo...'
    ],
    isLiked: true,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 3
  },
  {
    id: 'track_2',
    youtubeId: '4xDzrJKXOOY', // Synthwave chill radio
    title: 'Night Visions',
    artist: 'Signal Driver',
    album: 'Neon Horizon 1984',
    duration: 248,
    thumbnail: COVER_SYNTHWAVE,
    genre: 'Synthwave / Retro',
    lyrics: [
      'Cruising down the coastal highway at 2 AM',
      'Synthesizers glowing in the digital dashboard',
      'The horizon burns in chrome and crimson light',
      'Electric dreams passing through the optic lines',
      'Accelerating into the retro futuristic glow',
      'Never looking back, just following the neon sky'
    ],
    isLiked: true,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 2
  },
  {
    id: 'track_3',
    youtubeId: 'DWcJFNfaw9c', // Classical / Acoustic guitar Spanish style
    title: 'Corazón y Tierra',
    artist: 'Mateo & Ensamble Acústico',
    album: 'Madera y Sol',
    duration: 198,
    thumbnail: COVER_ACOUSTIC,
    genre: 'Acústico / Instrumental',
    lyrics: [
      'Cuerdas de nylon bajo el sol de la tarde',
      'El viento susurra entre los olivares antiguos',
      'Notas que recuerdan historias de antaño',
      'Un rasgueo suave que despierta el alma',
      'Tierra fértil, raíces profundas y melodía'
    ],
    isLiked: false,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 5
  },
  {
    id: 'track_4',
    youtubeId: '5qap5aO4i9A', // Lofi hip hop chill relaxing
    title: 'Pulse of Obsidian',
    artist: 'Audio Wave Lab',
    album: 'Minimalist Frequency 03',
    duration: 232,
    thumbnail: COVER_ELECTRONIC,
    genre: 'Electrónica / Minimal',
    lyrics: [
      'Oscilación sutil en frecuencias bajas',
      'Pulsos resonantes en el vacío',
      'Refracción de ondas en un prisma oscuro',
      'El bajo late a 124 BPM sincronizado',
      'Energía pura en movimiento constante'
    ],
    isLiked: false,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 1
  },
  {
    id: 'track_5',
    youtubeId: 'kJQP7kiw5Fk', // Despacito / Luis Fonsi
    title: 'Despacito',
    artist: 'Luis Fonsi ft. Daddy Yankee',
    album: 'Vida',
    duration: 282,
    thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
    genre: 'Latino / Pop',
    lyrics: [
      'Sí, sabes que ya llevo un rato mirándote',
      'Tengo que bailar contigo hoy',
      'Vi que tu mirada ya estaba llamándome',
      'Muéstrame el camino que yo voy',
      'Tú, tú eres el imán y yo soy el metal',
      'Me voy acercando y voy armando el plan',
      'Solo con pensarlo se acelera el pulso',
      'Despacito, quiero respirar tu cuello despacito...'
    ],
    isLiked: true,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 7
  },
  {
    id: 'track_6',
    youtubeId: 'fJ9rUzIMcZQ', // Queen - Bohemian Rhapsody
    title: 'Bohemian Rhapsody',
    artist: 'Queen',
    album: 'A Night at the Opera',
    duration: 359,
    thumbnail: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?auto=format&fit=crop&w=400&q=80',
    genre: 'Rock Clásico',
    lyrics: [
      'Is this the real life? Is this just fantasy?',
      'Caught in a landslide, no escape from reality',
      'Open your eyes, look up to the skies and see',
      'I\'m just a poor boy, I need no sympathy',
      'Because I\'m easy come, easy go, little high, little low',
      'Any way the wind blows doesn\'t really matter to me, to me'
    ],
    isLiked: true,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 10
  },
  {
    id: 'track_7',
    youtubeId: 'kXYiU_JCYtU', // Numb - Linkin Park
    title: 'Numb',
    artist: 'Linkin Park',
    album: 'Meteora',
    duration: 187,
    thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80',
    genre: 'Rock Alternativo',
    lyrics: [
      'I\'m tired of being what you want me to be',
      'Feeling so faithless, lost under the surface',
      'Don\'t know what you\'re expecting of me',
      'Put under the pressure of walking in your shoes',
      'I\'ve become so numb, I can\'t feel you there',
      'Become so tired, so much more aware'
    ],
    isLiked: false,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 4
  },
  {
    id: 'track_8',
    youtubeId: '7wtfhZwyrcc', // Imagine Dragons - Believer
    title: 'Believer',
    artist: 'Imagine Dragons',
    album: 'Evolve',
    duration: 204,
    thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=400&q=80',
    genre: 'Pop Rock',
    lyrics: [
      'First things first, I\'ma say all the words inside my head',
      'I\'m fired up and tired of the way that things have been, oh-ooh',
      'The way that things have been, oh-ooh',
      'Second things second, don\'t you tell me what you think that I can be',
      'I\'m the one at the sail, I\'m the master of my sea, oh-ooh'
    ],
    isLiked: false,
    addedAt: Date.now() - 1000 * 60 * 60 * 24 * 6
  }
];

export const INITIAL_PLAYLISTS: Playlist[] = [
  {
    id: 'playlist_favs',
    title: 'Canciones que te gustan',
    description: 'Colección automática de tus temas favoritos guardados con el corazón.',
    coverUrl: COVER_LOFI,
    accentColor: '#FF0033',
    trackIds: ['track_1', 'track_2', 'track_5', 'track_6'],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
    updatedAt: Date.now(),
    isSystem: true,
    isFavorites: true
  },
  {
    id: 'playlist_synth',
    title: 'Retro & Synthwave Vibes',
    description: 'Sintetizadores de medianoche y atmósferas cyberpunk para viajar y concentrarse.',
    coverUrl: COVER_SYNTHWAVE,
    accentColor: '#8b5cf6',
    trackIds: ['track_2', 'track_4'],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 2
  },
  {
    id: 'playlist_relax',
    title: 'Enfoque & Café Acústico',
    description: 'Guitarras de madera, grabaciones analógicas y beats lentos para estudio profundo.',
    coverUrl: COVER_ACOUSTIC,
    accentColor: '#d97706',
    trackIds: ['track_1', 'track_3'],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
    updatedAt: Date.now() - 1000 * 60 * 60 * 24 * 1
  },
  {
    id: 'playlist_energy',
    title: 'Energía & Rock Clásico',
    description: 'Selección de himnos inolvidables con voces épicas y riffs memorables.',
    coverUrl: COVER_ELECTRONIC,
    accentColor: '#ef4444',
    trackIds: ['track_6', 'track_7', 'track_8'],
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
    updatedAt: Date.now()
  }
];
